﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Cobalt.Models;
using Cobalt.Common;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Cobalt.PCLUnitTest
{
    [TestClass]
    public class CobaltUnitTest
    {
        [TestMethod]
        public async Task TestUserRegSecuess()
        {
            User _user = new User();
            _user.firstName = "Cobat10";
            _user.surname = "JC";
            _user.email = "coba1004@gmail.com";
            _user.password = "Coba@123";
            _user.confirmpassword = "Coba@123";
            User _NewUser = await Core.Register(_user);

            if (_NewUser != null)
            {
                Assert.IsNotNull(_NewUser.userid);
            }
            else
            {
                Assert.Inconclusive("FALIURE");
            }

        }

        [TestMethod]
        public async Task TestUserRegFaliure()
        {
            User _user = new User();
            _user.firstName = "Cobat123";
            _user.surname = "S";
            _user.email = null;
            _user.password = "Coba@123";
            _user.confirmpassword = "Coba@123";
            User _NewUser = await Core.Register(_user);

            if (_NewUser != null)
            {
                Assert.IsNotNull(_NewUser.userid);
                Debug.WriteLine("SCEUESS");
            }
            else
            {
                Debug.WriteLine("FALIURE");
            }
        }

        [TestMethod]
        public async Task TestUserTokenExitsUser()
        {
            User _user = new User();
            _user.firstName = "Cobat123";
            _user.surname = "S";
            _user.email = "coba03@gmail.com";
            _user.password = "Coba@123";
            _user.confirmpassword = "Coba@123";
            User _NewUser = await Core.Register(_user);

            if (_NewUser != null)
            {
                Assert.IsNotNull(_NewUser.userid);
                Assert.IsNotNull(_NewUser.userToken);
            }
            else
            {
                Debug.WriteLine("FALIURE");
            }
        }


        [TestMethod]
        public async Task TestUserRegAlredayExitsUser()
        {
            User _user = new User();
            _user.firstName = "Cobat123";
            _user.surname = "S";
            _user.email = "coba@gmail.com";
            _user.password = "Coba@123";
            _user.confirmpassword = "Coba@123";
            User _NewUser = await Core.Register(_user);

            if (_NewUser != null)
            {
                Assert.IsNotNull(_NewUser.userid);
            }
            else
            {
                Debug.WriteLine("FALIURE");
            }
        }

        [TestMethod]
        public void TestUserRegValditaion()
        {
            User _user = new User();
            _user.firstName = "Cobat123";
            _user.surname = "S";
            _user.email = "coba@gmail.com";
            _user.password = "Coba@123";
            _user.confirmpassword = "Coba@123";
            Error _error = ControlValidation.Register(_user);
            if (_error.hasError)
            {
                Debug.WriteLine(_error.errorMessage);
            }
            else
            {
                Debug.WriteLine("SUCESS");
            }
        }


        [TestMethod]
        public async Task TestLoginExitsUser()
        {
            User _usr = new User();
            _usr.email = "coba123@gmail.com";
            _usr.password = "Coba@123";
           

            LoggedInUser _User = await Core.Login(_usr);

          
            if (_User != null)
            {
              
                Assert.IsNotNull(_User.token);
            }
            else
            {
                Debug.WriteLine("FALIURE");
            }
        }

        [TestMethod]
        public async Task TestLoginNonExitsUser()
        {
            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobaabc@123";
            
            LoggedInUser _User = await Core.Login(_usr);

            if (_User != null)
            {

                Assert.IsNotNull(_User.token);
            }
            else
            {
                Debug.WriteLine("FALIURE");
            }
        }

        [TestMethod]
        public void TestUserEmailLoignValidate()
        {
            User _usr = new User();
            _usr.email = "cobagmail.com";
            _usr.password = "Cobaab3";


            Error _error = ControlValidation.Login(_usr);
            if (_error.hasError)
            {
                Debug.WriteLine(_error.errorMessage);
            }
            else
            {
                Debug.WriteLine("SUCESS");
            }

        }

        [TestMethod]
        public void TestUserPasswordLoignValidate()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobaab3";


            Error _error = ControlValidation.Login(_usr);
            if (_error.hasError)
            {
                Debug.WriteLine(_error.errorMessage);
            }
            else
            {
                Debug.WriteLine("SUCESS");
            }
        }

        [TestMethod]
        public void TestUserEmalPasswordLoignValidate()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalt@123";


            Error _error = ControlValidation.Login(_usr);
            if (_error.hasError)
            {
                Debug.WriteLine(_error.errorMessage);
            }
            else
            {
                Debug.WriteLine("SUCESS");
            }
        }

        [TestMethod]
        public async Task TestUserWrongPassword()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
           
        }


        [TestMethod]
        public async Task TestUserLockPassword()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

            for (int i = 0; i <= 3; i++)
            {

                User _User = await Core.AuthenticateUser(_usr);

                if (_User != null) //Successfully Logged in
                {
                    if (_User.status == 200) //logged in successfully
                    {
                        Debug.WriteLine("SUCESS");
                    }
                    else
                    {
                        Debug.WriteLine(_User.message);
                    }
                }
            }

        }


        [TestMethod]
        public async Task TestValaditeUsername()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

      

                User _User = await Core.AuthenticateUser(_usr);

                if (_User != null) //Successfully Logged in
                {
                    if (_User.status == 200) //logged in successfully
                    {
                        Debug.WriteLine("SUCESS");
                    }
                    else
                    {
                        Debug.WriteLine(_User.message);
                    }
                }
            }


        [TestMethod]
        public async Task TestValaditeCode()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";



            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
        }

        [TestMethod]
        public async Task TestMobileNumber()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";
            
            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
        }

        [TestMethod]
        public async Task TestChnagePassword()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
        }

        [TestMethod]
        public async Task TestChnagePasswordValdition()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
        }

        [TestMethod]
        public async Task TestChnagePasswordMisMatch()
        {

            User _usr = new User();
            _usr.email = "coba@gmail.com";
            _usr.password = "Cobalat@123";

            User _User = await Core.AuthenticateUser(_usr);

            if (_User != null) //Successfully Logged in
            {
                if (_User.status == 200) //logged in successfully
                {
                    Debug.WriteLine("SUCESS");
                }
                else
                {
                    Debug.WriteLine(_User.message);
                }
            }
        }


              
    }
}
