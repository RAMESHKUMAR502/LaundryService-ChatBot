﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace Cobalt.Views
{
    public partial class ChatBot : ContentPage
    {
        public ChatBot(string token="")
        {
            //InitializeComponent();
            Label header = new Label
            {
                Text = "WebView",
                FontSize = Device.GetNamedSize(NamedSize.Large, typeof(Label)),
                HorizontalOptions = LayoutOptions.Center
            };

            WebView webView = new WebView
            {
                Source = new UrlWebViewSource
                {
                    Url = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?s=abaXMIPkgbM.cwA.V98.k4iG8akLXPY_jFF2tSUQJ4dI8_bVGtdJUewXsGggXjs&usertoken=" + token,
                },
                VerticalOptions = LayoutOptions.FillAndExpand
            };

            // Accomodate iPhone status bar.
            this.Padding = new Thickness(10, Device.OnPlatform(20, 0, 0), 10, 5);

            // Build the page.
            this.Content = new StackLayout
            {
                Children =
                {
                  
                    webView
                }
            };
        }
    }
}
