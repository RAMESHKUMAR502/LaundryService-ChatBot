﻿namespace Cobalt.Models
{
    public class Error
    {
        public string errorMessage { get; set; }
        public bool hasError { get; set; }       
        public Error()
        {

        }
    }


}
