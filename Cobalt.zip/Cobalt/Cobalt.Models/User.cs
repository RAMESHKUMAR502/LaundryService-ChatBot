﻿namespace Cobalt.Models
{
    public class User
    {
        public string firstName { get; set; }
        public string surname { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string confirmpassword { get; set;}
        public string userid { get; set; }
        public string uniqueDeviceId { get; set; }
        public string mobileNumber { get; set; }

        public string isActive { get; set; }
        public string loginAttempt { get; set; }
        public string userToken { get; set; }
		public int status { get; set; }
		public string message { get; set; }
        public User()
        {

        }
    }


}
