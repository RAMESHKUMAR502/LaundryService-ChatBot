// WARNING
//
// This file has been generated automatically by Xamarin Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Cobalt.iOS
{
    [Register ("RegisterViewController")]
    partial class RegisterViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnHelp { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSubmit { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblConfirmPassowrdError { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblFirstNameError { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblPaswordError { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblUrNameError { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblUserNameError { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Cobalt.iOS.CustomUITextView txtConfirmPassword { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Cobalt.iOS.CustomUITextView txtEmail { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Cobalt.iOS.CustomUITextView txtFirstName { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Cobalt.iOS.CustomUITextView txtLastName { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        Cobalt.iOS.CustomUITextView txtPassowrd { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnHelp != null) {
                btnHelp.Dispose ();
                btnHelp = null;
            }

            if (btnSubmit != null) {
                btnSubmit.Dispose ();
                btnSubmit = null;
            }

            if (lblConfirmPassowrdError != null) {
                lblConfirmPassowrdError.Dispose ();
                lblConfirmPassowrdError = null;
            }

            if (lblFirstNameError != null) {
                lblFirstNameError.Dispose ();
                lblFirstNameError = null;
            }

            if (lblPaswordError != null) {
                lblPaswordError.Dispose ();
                lblPaswordError = null;
            }

            if (lblUrNameError != null) {
                lblUrNameError.Dispose ();
                lblUrNameError = null;
            }

            if (lblUserNameError != null) {
                lblUserNameError.Dispose ();
                lblUserNameError = null;
            }

            if (txtConfirmPassword != null) {
                txtConfirmPassword.Dispose ();
                txtConfirmPassword = null;
            }

            if (txtEmail != null) {
                txtEmail.Dispose ();
                txtEmail = null;
            }

            if (txtFirstName != null) {
                txtFirstName.Dispose ();
                txtFirstName = null;
            }

            if (txtLastName != null) {
                txtLastName.Dispose ();
                txtLastName = null;
            }

            if (txtPassowrd != null) {
                txtPassowrd.Dispose ();
                txtPassowrd = null;
            }
        }
    }
}