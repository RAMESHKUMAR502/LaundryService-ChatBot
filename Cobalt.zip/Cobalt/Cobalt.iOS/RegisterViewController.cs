using Foundation;
using System;
using UIKit;
using Cobalt.Models;
using Cobalt.Common;
using System.Drawing;
using CoreGraphics;

namespace Cobalt.iOS
{
	public partial class RegisterViewController : UIViewController
	{
		LoadingOverlay loadingOverlay;
private UIView activeview;             // Controller that activated the keyboard
private nfloat scrollamount = 0.0f;    // amount to scroll 
private nfloat bottom = 0.0f;           // bottom point
private nfloat offset = 120.0f;          // extra offset
private bool moveViewUp = false;           // which direction are we moving

		public RegisterViewController(IntPtr handle) : base(handle)
		{
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			NSNotificationCenter.DefaultCenter.AddObserver
(UIKeyboard.DidShowNotification, KeyBoardUpNotification);

			// Keyboard Down
			NSNotificationCenter.DefaultCenter.AddObserver
			(UIKeyboard.WillHideNotification, KeyBoardDownNotification);
			btnSubmit.TouchUpInside += Button_Click;
			btnSubmit.Enabled = false;

			//txtConfirmPassword.
			btnHelp.TouchUpInside += Help_Click;

			clearErrorText();
			ConfigureTextView();

		}

		private void KeyBoardUpNotification(NSNotification notification)
		{
			// get the keyboard size
			CGRect r = UIKeyboard.BoundsFromNotification(notification);

			// Find what opened the keyboard
			foreach (UIView view in this.View.Subviews)
			{
				if (view.IsFirstResponder)
					activeview = view;
			}

			// Bottom of the controller = initial position + height + offset      
			bottom = (activeview.Frame.Y + activeview.Frame.Height + offset);

			// Calculate how far we need to scroll
			scrollamount = (r.Height - (View.Frame.Size.Height - bottom));

			// Perform the scrolling
			if (scrollamount > 0)
			{
				moveViewUp = true;
				offset -= scrollamount;
                ScrollTheView(moveViewUp);
						}
			else
			{
				scrollamount = 0;
				offset = 120.0f;
				moveViewUp = false;
                ScrollTheView(moveViewUp);

			}
            
	

		}
	
	private void KeyBoardDownNotification(NSNotification notification)
	{
		if (moveViewUp) { ScrollTheView(false); }
	}

	private void ScrollTheView(bool move)
	{

		// scroll the view up or down
		UIView.BeginAnimations(string.Empty, System.IntPtr.Zero);
		UIView.SetAnimationDuration(0.3);

			CGRect frame = View.Frame;

		if (move)
		{
				frame.Y -= scrollamount;
		}
		else
		{
			frame.Y = 0;
			scrollamount = 0;
		}

		View.Frame = frame;
		UIView.CommitAnimations();
	}

		private void ConfigureTextView()
		{
           this.txtFirstName.EditingChanged += Validator.EmptyFieldValidator;
            this.txtLastName.EditingChanged += Validator.EmptyFieldValidator;
            this.txtEmail.EditingChanged += Validator.EmailValidator;
            this.txtPassowrd.EditingChanged += Validator.EmptyFieldValidator;
            this.txtConfirmPassword.EditingChanged += Validator.ConfirmPasswordValidator;
			Utility.ConfigureCoustomTesxtViw(this.txtFirstName,lblFirstNameError,"First name is must.",Enable_Submit);
			Utility.ConfigureCoustomTesxtViw(this.txtLastName, lblUrNameError,"Surname is must.",Enable_Submit);
			Utility.ConfigureCoustomTesxtViw(this.txtEmail, lblUserNameError,"Invalid Email.",Enable_Submit);
			Utility.ConfigureCoustomTesxtViw(this.txtPassowrd, lblPaswordError, "Password is must.",Enable_Submit);
                
			Utility.ConfigureCoustomTesxtViw(this.txtConfirmPassword, lblConfirmPassowrdError,"Password and Confirm Password must be same.",Enable_Submit,txtPassowrd);

		}

		private async void Help_Click(object sender, EventArgs e)
		{
			var cobbiController = Utility.GetViewController(Utility.MainStoryboard, "CobbiViewController") as CobbiViewController;
			cobbiController.SourceControll = this;
			cobbiController.ScreenName = "register";
			Utility.SetRootViewController(cobbiController, this, true);

		}

		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			txtEmail.Text="";
			txtPassowrd.Text="";
			 txtFirstName.Text="";
			 txtLastName.Text="";
			txtConfirmPassword.Text = "";
			clearErrorText();

		}

		private void clearErrorText()
		{
			lblUrNameError.Text = "";
			lblFirstNameError.Text = "";
			lblPaswordError.Text = "";
			lblConfirmPassowrdError.Text = "";
			lblUserNameError.Text = "";
		}

		private async void Enable_Submit(object sender, EventArgs e)
		{
			string _email = txtEmail.Text;
			string _password = txtPassowrd.Text;
			string _firstName = txtFirstName.Text;
			string _surname = txtLastName.Text;
			string _confirmpassword = txtConfirmPassword.Text;
			bool _isError = !lblUrNameError.Hidden || !lblPaswordError.Hidden || !lblUserNameError.Hidden || 
			                               !lblFirstNameError.Hidden || !lblConfirmPassowrdError.Hidden;

			btnSubmit.Enabled = !(string.IsNullOrEmpty(_email)
				|| string.IsNullOrEmpty(_password)
				|| string.IsNullOrEmpty(_firstName)
			    || string.IsNullOrEmpty(_surname)
			                      || string.IsNullOrEmpty(_confirmpassword)|| _isError);;
		}
		private async void Button_Click(object sender, EventArgs e)
		{
			btnSubmit.Enabled = false;

			User _user = new User
			{
				email = txtEmail.Text,
				password = txtPassowrd.Text,
				firstName = txtFirstName.Text,
				surname = txtLastName.Text,
				confirmpassword = txtConfirmPassword.Text,
				uniqueDeviceId = Core.GetDeviceId()
			};
			var bounds = UIScreen.MainScreen.Bounds;

			loadingOverlay = new LoadingOverlay(bounds);
			View.Add(loadingOverlay);
			Error _error = ControlValidation.Register(_user);

			if (_error.hasError)
			{
				string ErrorMessage = _error.errorMessage;
				Utility.Show_Alert(ErrorMessage);
			}
			else
			{
				
				string DeviceId = Core.GetDeviceId();
				_user.uniqueDeviceId = Convert.ToBase64String(Core.EncryptData(DeviceId));
				_user.mobileNumber = "0";
				_user.isActive = "1";
				_user.loginAttempt = "0";
				_user = await Core.Register(_user);
				if (_user != null)
				{
					_user.email = txtEmail.Text;
					_user.password = txtPassowrd.Text;

					KeychainHelpers.SaveCredentials(_user);
					var cobbiController = Utility.GetViewController(Utility.MainStoryboard, "CobbiViewController") as CobbiViewController;
					cobbiController.Tocken = _user.userToken;
					cobbiController.SourceControll = this;
					loadingOverlay.Hide();
					Utility.SetRootViewController(cobbiController, this, true);
				}
				else
				{
					
					loadingOverlay.Hide();
					Utility.Show_Alert("user already registered");
				}
			}

			btnSubmit.Enabled = true;
			loadingOverlay.Hide();
		}
	}
}