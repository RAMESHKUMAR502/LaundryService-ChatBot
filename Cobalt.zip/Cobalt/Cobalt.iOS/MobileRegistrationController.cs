using Foundation;
using System;
using UIKit;

namespace Cobalt.iOS
{
    public partial class MobileRegistrationController : UIViewController
    {
        public MobileRegistrationController (IntPtr handle) : base (handle)
        {
        }
    }
}