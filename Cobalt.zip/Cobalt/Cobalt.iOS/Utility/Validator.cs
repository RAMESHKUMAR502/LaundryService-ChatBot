﻿using System;
using System.Text.RegularExpressions;
using UIKit;

namespace Cobalt.iOS
{
	public class Validator
	{
		public Validator()
		{
		}
		public static void EmptyFieldValidator(object sender, EventArgs e)
		{
			CustomUITextView textField = ((CustomUITextView)sender);


			if (((CustomUITextView)sender).Text.Length <= 0)
			{
				// need to update on the main thread to change the border color
				//InvokeOnMainThread(() =>
				//{
				textField.ErrorLable.Text = textField.ErrorMessage;
				textField.BackgroundColor = UIColor.Yellow;
				textField.Layer.BorderColor = UIColor.Red.CGColor;
				textField.Layer.BorderWidth = 2;
				textField.ErrorLable.Hidden = false;

			}
			else
			{
				textField.ErrorLable.Text = "";
				textField.BackgroundColor = UIColor.White;
				textField.Layer.BorderColor = UIColor.Black.CGColor;
				textField.Layer.BorderWidth = 0;
				textField.ErrorLable.Hidden = true;
			

			}
			if (textField.Cb != null) textField.Cb(null,null);
		}


		public static void ConfirmPasswordValidator(object sender, EventArgs e)
		{
			CustomUITextView textField = ((CustomUITextView)sender);

			string errorMessage = string.Empty;
			if (textField.Text.Length <= 0)
			{
				errorMessage = "Confirm password is must";

			}
			else if (textField.CompareTextField.Text != textField.Text)
			{
				errorMessage = textField.ErrorMessage;
			}
			if (!string.IsNullOrEmpty(errorMessage))
			{
				textField.ErrorLable.Text = errorMessage;
				textField.BackgroundColor = UIColor.Yellow;
				textField.Layer.BorderColor = UIColor.Red.CGColor;
				textField.Layer.BorderWidth = 2;
				textField.ErrorLable.Hidden = false;

			}
			else
			{
				textField.ErrorLable.Text = "";
				textField.BackgroundColor = UIColor.White;
				textField.Layer.BorderColor = UIColor.Black.CGColor;
				textField.Layer.BorderWidth = 0;
				textField.ErrorLable.Hidden = true;



			}

			if (textField.Cb != null) textField.Cb(null,null);
		}

		public static void EmailValidator(object sender, EventArgs e)
		{
			CustomUITextView textField = ((CustomUITextView)sender);

			string errorMessage = string.Empty;
			string emailRegex = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";
			    
			if (textField.Text.Length <= 0)
			{
				errorMessage = "Email is must";

			}
				else if (!Regex.IsMatch(textField.Text, emailRegex, RegexOptions.IgnoreCase))
			{
				errorMessage = textField.ErrorMessage;
			}
			if (!string.IsNullOrEmpty(errorMessage))
			{
				textField.ErrorLable.Text = errorMessage;
				textField.BackgroundColor = UIColor.Yellow;
				textField.Layer.BorderColor = UIColor.Red.CGColor;
				textField.Layer.BorderWidth = 2;
				textField.ErrorLable.Hidden = false;

			}
			else
			{
				textField.ErrorLable.Text = "";
				textField.BackgroundColor = UIColor.White;
				textField.Layer.BorderColor = UIColor.Black.CGColor;
				textField.Layer.BorderWidth = 0;
				textField.ErrorLable.Hidden = true;



			}
			if (textField.Cb != null) textField.Cb(null,null);
		}
	}

}
