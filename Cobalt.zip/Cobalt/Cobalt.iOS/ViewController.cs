﻿using System;

using UIKit;
using Cobalt.Common;
using Foundation;
using CoreGraphics;

namespace Cobalt.iOS
{
	public partial class ViewController : UIViewController
	{
		
		NSTimer timer;
		public ViewController (IntPtr handle) : base (handle)
		{
		}


		void AddBackground()
		{
			var bgImg = UIImage.FromFile("Images/icon.png");
			//bgImg = bgImg.StretchableImage((int)bgImg.Size.Width / 2 - 1, (int)bgImg.Size.Height / 2 - 1);
			var rect = new CGRect(140.0f, 100.0f, 100.0f, 100.0f);
			var bgView = new UIImageView(rect);
			bgView.Center = new CGPoint(View.Center.X, View.Center.Y - 100);

			//	bgView.AutoresizingMask = UIViewAutoresizing.FlexibleDimensions;
			bgView.Image = bgImg;
			View.AddSubview(bgView);
			View.SendSubviewToBack(bgView);
		}
		void AddProgressBar()
		{
			//var rect = new CGRect(140.0f, 100.0f, 200.0f, 200.0f);
			//rect.Height = 100.0f;
			// labeledProgressView = new LabeledCircularProgressView(rect);

			//labeledProgressView.RoundedCorners = true;

			//labeledProgressView.ProgressTintColor = UIColor.DarkGray;

			//labeledProgressView.Center = new CGPoint(View.Center.X, View.Center.Y - 100);
		//	labeledProgressView.ThicknessRatio = 0.05f;
		//	labeledProgressView.TrackTintColor = UIColor.Gray;
			//View.AddSubview(labeledProgressView);
		}
		void startTimer()
		{
			int progress = 0;
			timer = NSTimer.CreateRepeatingScheduledTimer(1.0 / 30.0, delegate
			{
				progress += 100;
				float pr = progress / 100.0f;


		//		labeledProgressView.Progress = pr;
		//		labeledProgressView.ProgressLabel.Text = pr.ToString("0%");
				if (progress >= 100)
				{
					timer.Invalidate();
					timer = null;
					var LoginController = Utility.GetViewController(Utility.MainStoryboard, "LoginViewController") as LoginViewController;
					Utility.SetRootViewController(LoginController,this ,true);

				}

			});
		}


		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			AddProgressBar();
			//	AddBackground();

			startTimer();


		}

		public override void DidReceiveMemoryWarning ()
		{
			base.DidReceiveMemoryWarning ();
			// Release any cached data, images, etc that aren't in use.
		}
	}
}

