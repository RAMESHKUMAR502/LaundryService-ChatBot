using Foundation;
using System;
using UIKit;

namespace Cobalt.iOS
{
	public partial class CobbiViewController : UIViewController
	{
		public string Tocken { get; set; }
		public UIViewController SourceControll { get; set; }
		public string ScreenName { get; set;}
		LoadingOverlay loadingOverlay;
        public CobbiViewController (IntPtr handle) : base (handle)
        {
        }
		public override void ViewDidLoad()
		{
			string token = Tocken;
			//var url = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?s=abaXMIPkgbM.cwA.V98.k4iG8akLXPY_jFF2tSUQJ4dI8_bVGtdJUewXsGggXjs=" +  "&screen=" +this.ScreenName;


			var url = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?s=OKa-AA9fWNc.cwA.3L0.x3nOS2l7a7MvbNirrG8H18e3m8dIbPzBjW4QHI-vhTY";
			if (!string.IsNullOrEmpty(token))
				url += "&usertoken=" + token; ;
			url += "&screen=" + this.ScreenName; ;
			webView.LoadRequest(new NSUrlRequest(new NSUrl(url)));

			var bounds = UIScreen.MainScreen.Bounds;

			// show the loading overlay on the UI thread using the correct orientation sizing
			loadingOverlay = new LoadingOverlay(bounds);
			View.Add(loadingOverlay);
			webView.LoadFinished += (object sender, EventArgs e) =>
			{
				loadingOverlay.Hide();
				SetBackButton();
			};
		}
		private void SetBackButton()
		{
			UIBarButtonItem backbutton = new UIBarButtonItem();
			backbutton.Title = "Back";
			backbutton.Clicked += (o, e) =>
			{
				//var LoginController = Utility.GetViewController(Utility.MainStoryboard, "LoginViewController") as LoginViewController;
				Utility.SetRootViewController(SourceControll, this, true);

			};
			this.NavigationItem.LeftBarButtonItem = backbutton;
		}
    }
}