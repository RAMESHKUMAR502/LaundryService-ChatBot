﻿using Cobalt.Models;
using System.Text.RegularExpressions;

namespace Cobalt.Common
{
    public class ControlValidation
    {

        /// <summary>
        /// Login error handling
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static Error Login(User user)
        {
            string ErrorMessage = string.Empty;           
            string sEmail = string.Empty;
            string sPassword = string.Empty;
            Error _error = new Error();
            _error.hasError = false;          
            sEmail = user.email;
            sPassword = user.password;

            #region - Validation for Login

            if (string.IsNullOrEmpty(sEmail))
            {
                ErrorMessage = ErrorMessage + "Email is must.";
            }
            else
            {
                bool isEmail = Regex.IsMatch(sEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                if (!isEmail)
                {
                    ErrorMessage = ErrorMessage + "Invalid Email.";
                }
            }

            if (string.IsNullOrEmpty(sPassword))
            {
                ErrorMessage = ErrorMessage + "Password is must.";
            }

            if (ErrorMessage.Trim().Length > 0)
            {
                _error.hasError = true;
            }
            _error.errorMessage = ErrorMessage;

            #endregion

            return _error;

        }

        /// <summary>
        /// Registration error handling
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static Error Register(User user)
        {
            string ErrorMessage = string.Empty;
            string sFirstName = string.Empty;
            string sSurname = string.Empty;
            string sEmail = string.Empty;
            string sPassword = string.Empty;
            string sConfirmPassword = string.Empty;
            Error _error = new Error();
            _error.hasError = false;
            sFirstName = user.firstName;
            sSurname = user.surname;
            sEmail = user.email;
            sPassword = user.password;
            sConfirmPassword = user.confirmpassword;
            #region - Validation for Registration
            
            if (string.IsNullOrEmpty(sFirstName))
            {
                ErrorMessage = ErrorMessage + "first name is must.";
            }

            if (string.IsNullOrEmpty(sSurname))
            {
                ErrorMessage = ErrorMessage + "surname is must.";
            }

            if (string.IsNullOrEmpty(sEmail))
            {
                ErrorMessage = ErrorMessage + "Email is must.";
            }
            else
            {
                bool isEmail = Regex.IsMatch(sEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                if (!isEmail)
                {
                    ErrorMessage = ErrorMessage + "Invalid Email.";
                }
            }

            if (string.IsNullOrEmpty(sPassword))
            {
                ErrorMessage = ErrorMessage + "Password is must.";
            }
            else
            {
                bool isValidPassword = Regex.IsMatch(sPassword, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}", RegexOptions.IgnoreCase);
                if (!isValidPassword)
                {
                    ErrorMessage = ErrorMessage + "Password must contain: Minimum 8 characters atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character";
                }
            }

            if (string.IsNullOrEmpty(sConfirmPassword))
            {
                ErrorMessage = ErrorMessage + "Confirm password is must.";
            }
            else
            {
                bool isValidConfirmPassword = Regex.IsMatch(sConfirmPassword, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}", RegexOptions.IgnoreCase);
                if (!isValidConfirmPassword)
                {
                    ErrorMessage = ErrorMessage + "Password must contain: Minimum 8 characters atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character";
                }
            }
            if (!string.IsNullOrEmpty(sPassword) && !string.IsNullOrEmpty(sConfirmPassword))
            {
                sPassword = sPassword.ToLower().Trim();
                sConfirmPassword = sConfirmPassword.ToLower().Trim();
                if(sPassword!=sConfirmPassword)
                {
                    ErrorMessage = ErrorMessage + "Password and Confirm Password must be same.";
                }
            }

            if(ErrorMessage.Trim().Length>0)
            {
                _error.hasError = true;
            }
            _error.errorMessage = ErrorMessage;
            #endregion

            return _error;
        }
    }
}