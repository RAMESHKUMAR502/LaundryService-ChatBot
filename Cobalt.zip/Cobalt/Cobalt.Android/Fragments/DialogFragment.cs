using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;

namespace Cobalt.Android.Fragments
{
    public class DialogFragmentSample : DialogFragment
    {

        public static DialogFragmentSample NewInstace(Bundle bundle)
        {
            var fragment = new DialogFragmentSample();
            fragment.Arguments = bundle;
            return fragment;
        }
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.ForgotPwdlayout, container, false);
            Button Canclebutton = view.FindViewById<Button>(Resource.Id.btnClearLL);
            Button RestPasword = view.FindViewById<Button>(Resource.Id.btnLoginLL);
            Dialog.Window.RequestFeature(WindowFeatures.NoTitle); //remove title area
            Dialog.SetCanceledOnTouchOutside(false); //dismiss window on touch outside

            Canclebutton.Click += delegate {
                Dismiss();
               // Toast.MakeText(Activity, "Dialog fragment dismissed!", ToastLength.Short).Show();
            };

            RestPasword.Click += RestPasword_Click;
            return view;
            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        private void RestPasword_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch(Exception ex)
            {

            }
        }
    }
}