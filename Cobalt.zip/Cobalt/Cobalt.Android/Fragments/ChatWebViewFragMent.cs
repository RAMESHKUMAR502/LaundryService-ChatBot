using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Fragment = Android.Support.V4.App.Fragment;
using FloatingActionButton = Clans.Fab.FloatingActionButton;
using Android.Webkit;
using Cobalt.Android.Helper;
using Cobalt.Android.Utils;
using Android.Graphics;
using Android.Net.Http;

namespace Cobalt.Android.Fragments
{
    public class ChatWebViewFragMent : Fragment
    {
        ProgressDialog prDialog;
       public WebView mWebView;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            return inflater.Inflate(Resource.Layout.ChatWebviewlayout, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            mWebView = view.FindViewById<WebView>(Resource.Id.webView);
            mWebView.Settings.JavaScriptEnabled = true;
            mWebView.Settings.SetPluginState(WebSettings.PluginState.On);
            mWebView.SetWebViewClient(new MyWebViewClient(this.Activity));
 
            string URI = Constants.CHATBOTWEBVIEW + AppSharedPreferencesSingleton.GetInstance().getAccessKey("token");
            //Load url to be randered on WebView
            mWebView.LoadUrl(URI);
           

        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }

     }

    public class MyWebViewClient : WebViewClient
    {
        ProgressDialog progress;
        public Activity mActivity;
        public MyWebViewClient(Activity mActivity)
        {
            this.mActivity = mActivity;
        }
        public override bool ShouldOverrideUrlLoading(WebView view, string url)
        {
            progress = ProgressDialog.Show(mActivity, "Loading...", "Please Wait (about 4 seconds)", true);
            if (progress != null)
            {
                if (progress.IsShowing == false)
                    Toast.MakeText(mActivity, "Loading...", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(mActivity, "Loading...", ToastLength.Long).Show();
            }
            view.LoadUrl(url);
            return true;
        }

        public override void OnPageStarted(WebView view, string url, Bitmap favicon)
        {
            progress = ProgressDialog.Show(mActivity, "Loading...", "Please Wait..", true);

            if (progress != null && !progress.IsShowing)
            {
                progress.Show();
            }
             Toast.MakeText(mActivity, "Processing...", ToastLength.Long).Show();

            base.OnPageStarted(view, url, favicon);
        }

        public override void OnPageFinished(WebView view, string url)
        {
            if (progress != null && progress.IsShowing)
                progress.Dismiss();

            base.OnPageFinished(view, url);
        }
        public override void OnReceivedSslError(WebView view, SslErrorHandler handler, SslError error)
        {
            handler.Proceed();
            base.OnReceivedSslError(view, handler, error);
        }

        public override void OnReceivedError(WebView view, [GeneratedEnum] ClientError errorCode, string description, string failingUrl)
        {
            if (progress != null && progress.IsShowing)
                progress.Dismiss();
            base.OnReceivedError(view, errorCode, description, failingUrl);
        }
       
    }
}