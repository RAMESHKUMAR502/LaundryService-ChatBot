using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;

using Fragment = Android.Support.V4.App.Fragment;
using FloatingActionButton = Clans.Fab.FloatingActionButton;
using Cobalt.Android.Helper;

namespace Cobalt.Android.Fragments
{
    public class Home_Fragment : Fragment
    {
        ClassMenu cl;
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
             return inflater.Inflate(Resource.Layout.Home_Fragment, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            cl = view.FindViewById<ClassMenu>(Resource.Id.circular_layout);

            cl.addMenuItem("one", 1, Resource.Drawable.Car);
            cl.addMenuItem("two", 2, Resource.Drawable.House);
            cl.addMenuItem("three", 3, Resource.Drawable.Car);
            cl.addMenuItem("ten", 10, Resource.Drawable.House);
             if (cl != null)
            {

            }

        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }
 }
}