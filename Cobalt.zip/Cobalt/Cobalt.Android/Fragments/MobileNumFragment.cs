using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using static Android.App.ActionBar;
using Fragment = Android.Support.V4.App.Fragment;
using Cobalt.Android.Activites;
using Cobalt.Android.Utils;

namespace Cobalt.Android.Fragments
{
    public class MobileNumFragment :Fragment
    {
        private EditText mPhoneNumber;
        private Button mSmsButton;
        private TextView AlredayView;

        ActivityType ActivityEnuType;

        Com.Hbb20.CountryCodePicker ccp;



        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            return inflater.Inflate(Resource.Layout.SendSMSlayout, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            LinearLayout linearlayout = (LinearLayout)view.FindViewById(Resource.Id.linearlayout);
            ccp = new Com.Hbb20.CountryCodePicker(view.Context);
            if (ccp != null)
            {
                LayoutParams LayoutParams = new LayoutParams(LayoutParams.MatchParent, LayoutParams.WrapContent);
                ccp.SetCountryForNameCode("US");
                ccp.ShowFullName(true);
                ccp.SetHorizontalGravity(GravityFlags.CenterHorizontal);
                ccp.SetTextSize(26);
                ccp.LayoutParameters = LayoutParams;
                linearlayout.AddView(ccp);

            }
            mPhoneNumber = (EditText)view.FindViewById(Resource.Id.phoneNumber);
            mSmsButton = (Button)view.FindViewById(Resource.Id.smsVerificationButton);
            mSmsButton.Click += MSmsButton_Click; ;
  
            AlredayView = (TextView)view.FindViewById(Resource.Id.tvLoginLink);

            mPhoneNumber.AfterTextChanged += _Email_AfterTextChanged;
            mSmsButton.Enabled = false;
            mSmsButton.Alpha = 0.5f;
            AlredayView.Click += AlredayView_Click;

            
        }

        public void ActivityType(ActivityType actvtyType)
        {
            ActivityEnuType = actvtyType;
        }

        private void _Email_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(mPhoneNumber.Text.ToString()))
                {
                    mSmsButton.Alpha = 0.5f;
                    mSmsButton.Enabled = false;
                }
                else
                {
                    mSmsButton.Alpha = 1.0f;
                    mSmsButton.Enabled = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }




        private void AlredayView_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                this.Activity.Finish();
            }
            catch (Exception ex)
            {

            }

        }

        private void MSmsButton_Click(object sender, EventArgs e)
        {
           if(!validate())
            {
                return;
            }
          
            //();
        }

   
        public bool validate()
        {
            bool valid = true;

            string email = mPhoneNumber.Text.ToString();


            if (string.IsNullOrEmpty(email))
            {
                mPhoneNumber.Error = GetString(Resource.String.enterphonenumber);
                valid = false;
            }
            else
            {
                mPhoneNumber.Error = null;
            }
            return valid;
        }

    }
}