using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;
using Cobalt.Android.Helper;

namespace Cobalt.Android.Activites
{
    // [Activity(Label = "StartprovisionActivity")]
    [Activity(Label = "StartprovisionActivity", ScreenOrientation = ScreenOrientation.Portrait)]
    public class StartprovisionActivity : AppComCustomeActivty
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Startprovisionlayout);
            Button btn = FindViewById<Button>(Resource.Id.okGoit);
            btn.Click += Btn_Click;

            // Create your application here
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(HomePage)));
                Finish();
            }
            catch (Exception ex)
            {

            }
        }
    }
}