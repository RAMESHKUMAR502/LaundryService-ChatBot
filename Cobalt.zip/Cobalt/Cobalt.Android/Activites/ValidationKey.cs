using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;
using Cobalt.Android.Helper;

namespace Cobalt.Android.Activites
{
    // [Activity(Label = "ValidationKey")]
    [Activity(Label = "ValidationKey", ScreenOrientation = ScreenOrientation.Portrait)]
    public class ValidationKey : AppComCustomeActivty
    {
        EditText EditTxet;
        Button Validatebtn;
        TextView ResendTxtView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.activity_verification);
            // Create your application here

            EditTxet = (EditText)FindViewById(Resource.Id.et_code1);
            Validatebtn = (Button)FindViewById(Resource.Id.btn_validate);
            ResendTxtView = (TextView)FindViewById(Resource.Id.tv_resend_otp);
            Validatebtn.Click += Validatebtn_Click;
            ResendTxtView.Click += ResendTxtView_Click;
        }

        private void ResendTxtView_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch(Exception ex)
            {

            }
        }

        private void Validatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Validate())
                    return;

                StartActivity(new Intent(Application.Context, typeof(ValidationKey)));
                Finish();

            }
            catch (Exception ex)
            {

            }
        }
        public bool Validate()
        {

            bool valid = true;
            try
            {


                string email = EditTxet.Text.ToString();


                if (string.IsNullOrEmpty(email))
                {
                    EditTxet.Error = GetString(Resource.String.enterphonenumber);
                    valid = false;
                }
                else
                {
                    EditTxet.Error = null;
                }


            }
            catch (Exception ex)
            {

            }
            return valid;
        }
    }
}