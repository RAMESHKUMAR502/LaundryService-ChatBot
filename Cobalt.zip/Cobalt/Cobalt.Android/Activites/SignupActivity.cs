using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;
using Android.Util;
using Cobalt.Common;
using Cobalt.Models;
using Cobalt.Android.Utils;
using Android.Content.PM;
using System.Text.RegularExpressions;
using Android.Support.Design.Widget;
using Android.Webkit;
using Android.Graphics;
using Android.Net.Http;

namespace Cobalt.Android.Activites
{
   // [Activity(Label = "SignupActivity")]
    [Activity(Label = "SignupActivity", ScreenOrientation = ScreenOrientation.Portrait)]

    public class SignupActivity : AppComCustomeActivty
    {
          EditText _nameText;
           EditText _emailText;
          EditText _SurnameText;
          EditText _passwordText;
          EditText _reEnterPasswordText;
          Button _signupButton;
          TextView _loginLink;
        TextInputLayout til;
        TextInputLayout tilpwd;
        TextView _ImgView;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Signuplayout);

            _nameText = FindViewById<EditText>(Resource.Id.input_name);
            _SurnameText = FindViewById<EditText>(Resource.Id.input_SurName);
            _emailText = FindViewById<EditText>(Resource.Id.input_email);
            _passwordText = FindViewById<EditText>(Resource.Id.input_password);
            _reEnterPasswordText = FindViewById<EditText>(Resource.Id.input_reEnterPassword);
            _signupButton = FindViewById<Button>(Resource.Id.btn_signup);
            _loginLink = FindViewById<TextView>(Resource.Id.link_login);

            _ImgView = FindViewById<TextView>(Resource.Id.help_icon);

            _ImgView.Click += _ImgView_Click;
            til = FindViewById<TextInputLayout>(Resource.Id.Txtinput_reEnterPassword);
            tilpwd = FindViewById<TextInputLayout>(Resource.Id.Txtinput_Password);
            _passwordText.FocusChange += _passwordText_FocusChange;
            _reEnterPasswordText.FocusChange += _reEnterPasswordText_FocusChange;
            _nameText.AfterTextChanged += _nameText_AfterTextChanged;
            _reEnterPasswordText.AfterTextChanged += _nameText_AfterTextChanged;
            _SurnameText.AfterTextChanged += _nameText_AfterTextChanged;
            _passwordText.AfterTextChanged += _nameText_AfterTextChanged;
            _emailText.AfterTextChanged += _nameText_AfterTextChanged;
            _signupButton.Enabled = false;
            _signupButton.Click += _signupButton_Click;
            _loginLink.Click += _loginLink_Click;
            _signupButton.Alpha = 0.5f;

            // Create your application here
        }

        private void _passwordText_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                tilpwd.Error = GetString(Resource.String.PwdCmplxError);
                tilpwd.ErrorEnabled = true;
            }
            else
                tilpwd.ErrorEnabled = false;
            
        }

        private void _reEnterPasswordText_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                til.Error = GetString(Resource.String.PwdCmplxError);
                til.ErrorEnabled = true;
            }
            else
                til.ErrorEnabled = false;
        }

        private void _ImgView_Click(object sender, EventArgs e)
        {
            try
            {

                var intent = new Intent(Application.Context, typeof(CobieWbviewActivity));
                intent.PutExtra("weburi", Constants.CobiregUi);

                StartActivity(intent);

                // StartActivity(new Intent(Intent.ActionView, global::Android.Net.Uri.Parse(Constants.CobiregUi)));
            }
            catch (Exception ex)
            {

            }
        }

           

        private void _nameText_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(_nameText.Text.ToString()) || string.IsNullOrEmpty(_SurnameText.Text.ToString())
                    || string.IsNullOrEmpty(_emailText.Text.ToString()) || string.IsNullOrEmpty(_passwordText.Text.ToString())
                    || string.IsNullOrEmpty(_reEnterPasswordText.Text.ToString()))
                {
                  
                    _signupButton.Alpha = 0.5f;
                    _signupButton.Enabled = false;
                }
                else
                {
                    _signupButton.Alpha = 1.0f;
                    _signupButton.Enabled = true;
                }

            }
            catch(Exception ex)
            {

            }
        }

        private void _loginFingerprint_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                Finish();
            }
            catch (Exception ex)
            {

            }
        }

        private void _loginLink_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                Finish();
            }
            catch(Exception ex)
            {

            }
        }

        private void _signupButton_Click(object sender, EventArgs e)
        {
            try
            {
                signup();
              
            }
            catch(Exception ex)
            {

            }
        }

        #region SIGNUP


        public async void signup()
        {

            ProgressDialog dialog = ProgressDialog.Show(this, GetString(Resource.String.Lgin), GetString(Resource.String.CrAccount), true, false);
            try
            {
                if (!validate())
                {
                    dialog.Hide();
                    onSignupFailed();
                    return;
                }

                _signupButton.Enabled = false;
                string DevcieId = Core.GetDeviceId();

                dialog.Show();

                string name = _nameText.Text.ToString();
                string email = _emailText.Text.ToString();
                string SurName = _SurnameText.Text.ToString();
                string password = _passwordText.Text.ToString();
                string reEnterPassword = _reEnterPasswordText.Text.ToString();

               

                User _user = new User();
                _user.firstName = name;
                _user.surname = SurName;
                _user.email = email;
                _user.password = password;
                _user.confirmpassword = reEnterPassword;

                Error _error = ControlValidation.Register(_user);
                if (_error.hasError)
                {
                    dialog.Hide();
                    string ErrorMessage = _error.errorMessage;
                    Toast.MakeText(this, ErrorMessage, ToastLength.Short).Show();

                    return;
                }
                string DeviceId = Core.GetDeviceId();    
                string encryptedDeviceId= Convert.ToBase64String(Core.EncryptData(DeviceId));
                _user.uniqueDeviceId = encryptedDeviceId;
                _user.mobileNumber = "0";
                _user.isActive = "1";
                _user.loginAttempt = "0";
                User _NewUser = await Core.Register(_user);

                if(_NewUser != null)
                {
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("username", _emailText.Text.ToString());
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Password", _passwordText.Text.ToString());

                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("firstname", _nameText.Text.ToString());
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("surname", _SurnameText.Text.ToString());

                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("islogin", "true");
                    string EncpUserid = AppSharedPreferencesSingleton.GetInstance().encrypt(_NewUser.userid);

                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("userid", EncpUserid);

                    string DecrpdeviceID = null;
                    if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId")))
                    {
                        DecrpdeviceID = AppSharedPreferencesSingleton.GetInstance().decrypt(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId"));

                    }

                    bool isValidDevice = false;

                    if (DecrpdeviceID != null && _NewUser.uniqueDeviceId != null)
                        isValidDevice = Core.ValidateDevice(DecrpdeviceID, _NewUser.uniqueDeviceId);


                    //string DevcieId = Core.GetDeviceId(); 
                    if (_NewUser.uniqueDeviceId != null)
                    {
                        string EncpdeviceID = AppSharedPreferencesSingleton.GetInstance().encrypt(_NewUser.uniqueDeviceId);

                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("UnquieDeviceId", EncpdeviceID);
                    }

                    if (_NewUser.mobileNumber != null)
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Mobile", _NewUser.mobileNumber);
                    if (_NewUser.isActive != null)
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("isActive", _NewUser.isActive);
                    if (_NewUser.userToken != null)
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("token", _NewUser.userToken);

                 

                    dialog.Hide();
                    onSignupSuccess(isValidDevice);
                }
                else
                {
                    dialog.Hide();
                    onSignupFailed();
                }


              

            }
            catch (Exception ex)
            {
                onSignupFailed();
                dialog.Hide();
            }
    }

#endregion

#region VALDIATE
        public void onSignupSuccess(bool isValidDevice = false)
        {
            _signupButton.Enabled = true;
            SetResult(Result.Ok);
            if (isValidDevice == true)
                StartActivity(new Intent(Application.Context, typeof(HomePage)));
            else
                StartActivity(new Intent(Application.Context, typeof(StartprovisionActivity)));
            Finish();
        }

        public void onSignupFailed()
        {
            Toast.MakeText(this, Resource.String.UserExistsError, ToastLength.Short).Show();

            _signupButton.Enabled = true;
        }

        public bool IsName(string input)
        {
            if (string.IsNullOrEmpty(input)) return false;
            var hasNumber = new Regex(@"[0-9]+");
            var hasUpperChar = new Regex(@"[A-Z]+");
            var hasMinimum8Chars = new Regex(@"[a-z]");

            bool isValidated = hasNumber.IsMatch(input) || hasUpperChar.IsMatch(input) || hasMinimum8Chars.IsMatch(input);
                   
            return isValidated;
        } // end method validateFirstNa

        //"^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!*@#$%^&+=]).*$"
        public bool IsvalidPassword(string apasswrd)
        {
            if (string.IsNullOrEmpty(apasswrd)) return false;
            if (System.Text.RegularExpressions.Regex.Match(apasswrd, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}").Success) return true;
            return false;
        }        


        public bool validate()
        {
            bool valid = true;

            string name = _nameText.Text.ToString();

            string email = _emailText.Text.ToString();
            string SurName = _SurnameText.Text.ToString();
            string password = _passwordText.Text.ToString();
            string reEnterPassword = _reEnterPasswordText.Text.ToString();

            if (!IsName(name))
            {
                _nameText.Error = GetString(Resource.String.FirstNameError);
                valid = false;
            }
            else
            {
                _nameText.Error = null;
            }

            if (!IsName(SurName))
            {
                _SurnameText.Error = GetString(Resource.String.SurNameError);
                valid = false;
            }
            else
            {
                _SurnameText.Error = null;
            }
             

            if (string.IsNullOrEmpty(email) || !Patterns.EmailAddress.Matcher(email).Matches())
            {
                _emailText.Error = GetString(Resource.String.InvalidEmailError);
                valid = false;
            }
            else
            {
                _emailText.Error = null;
            }

            if (!IsvalidPassword(password))
            {
                _passwordText.Error = GetString(Resource.String.PwdCmplxError);
                valid = false;
            }
            else
            {
                _passwordText.Error = null;
            }

            if (!IsvalidPassword(reEnterPassword))
            {
                _reEnterPasswordText.Error = GetString(Resource.String.PwdCmplxError);
                valid = false;
            }
            else
            {
                _passwordText.Error = null;
            }

            //  //    if (string.IsNullOrEmpty(reEnterPassword) || !IsvalidPassword(reEnterPassword) || !(reEnterPassword.Equals(password)))
            if (!string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(reEnterPassword))          
            {
                if(password!= reEnterPassword)
                { 
                _reEnterPasswordText.Error = GetString(Resource.String.PwdErrNotMatch);
                valid = false;
                }
            }
            else
            {
                _reEnterPasswordText.Error = null;
            }

            return valid;
        }

#endregion
    }

    public class SignUpWebViewClient : WebViewClient
    {
        ProgressDialog progress;
        public Activity mActivity;
        public SignUpWebViewClient(Activity mActivity)
        {
            this.mActivity = mActivity;
        }
        public override bool ShouldOverrideUrlLoading(WebView view, string url)
        {
            progress = ProgressDialog.Show(mActivity, "Loading...", "Please Wait (about 4 seconds)", true);
            if (progress != null)
            {
                if (progress.IsShowing == false)
                    Toast.MakeText(mActivity, "Loading...", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(mActivity, "Loading...", ToastLength.Long).Show();
            }
            view.LoadUrl(url);
            return true;
        }

        public override void OnPageStarted(WebView view, string url, Bitmap favicon)
        {
            progress = ProgressDialog.Show(mActivity, "Loading...", "Please Wait..", true);

            if (progress != null && !progress.IsShowing)
            {
                progress.Show();
            }
            Toast.MakeText(mActivity, "Processing...", ToastLength.Long).Show();

            base.OnPageStarted(view, url, favicon);
        }

        public override void OnPageFinished(WebView view, string url)
        {
            if (progress != null && progress.IsShowing)
                progress.Dismiss();

            base.OnPageFinished(view, url);
        }
        public override void OnReceivedSslError(WebView view, SslErrorHandler handler, SslError error)
        {
            handler.Proceed();
            base.OnReceivedSslError(view, handler, error);
        }

        public override void OnReceivedError(WebView view, [GeneratedEnum] ClientError errorCode, string description, string failingUrl)
        {
            if (progress != null && progress.IsShowing)
                progress.Dismiss();
            base.OnReceivedError(view, errorCode, description, failingUrl);
        }

    }
}