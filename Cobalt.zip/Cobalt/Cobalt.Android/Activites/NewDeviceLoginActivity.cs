﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fragment = Android.Support.V4.App.Fragment;
using FragmentTransaction = Android.Support.V4.App.FragmentTransaction;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Cobalt.Android.Fragments;

namespace Cobalt.Android.Activites
{
    [Activity(Label = "NewDeviceLoginActivity")]
    public class NewDeviceLoginActivity : AppCompatActivity
    {

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.forgotPwdFlowlayout);

            if (savedInstanceState == null)
            {
                EmailDialogFragment EmailDialogFragment = new EmailDialogFragment();
                EmailDialogFragment.ActivityType(Utils.ActivityType.NEWCEVICEREG);
                SupportFragmentManager.BeginTransaction().Add(Resource.Id.fragment,EmailDialogFragment).Commit();
            }

            // Create your application here
        }

        Fragment fragment = null;
        public void ChangeFrga(string aType)
        {
            ((InputMethodManager)this.GetSystemService(Context.InputMethodService)).HideSoftInputFromWindow(this.CurrentFocus.ApplicationWindowToken, 0);


            fragment = null;
            FragmentTransaction ft = SupportFragmentManager.BeginTransaction();
            if (aType == "Validate")
            {
                ValidateDialogFragment ValidateDialogFragment = new ValidateDialogFragment();
                ValidateDialogFragment.ActivityType(Utils.ActivityType.NEWCEVICEREG);
                fragment = ValidateDialogFragment;
                ft.Replace(Resource.Id.fragment, fragment).Commit();

            }
            if (aType == "MobileNumber")
            {
                MobileNumFragment MobileNumFragment = new MobileNumFragment();
                MobileNumFragment.ActivityType(Utils.ActivityType.NEWCEVICEREG);
                fragment = MobileNumFragment;
                ft.Replace(Resource.Id.fragment, fragment).Commit();

            }
                       
        }
    }
}