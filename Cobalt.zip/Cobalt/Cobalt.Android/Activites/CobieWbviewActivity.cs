﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;
using Android.Webkit;
using Cobalt.Android.Fragments;
using Cobalt.Android.Utils;
using Cobalt.Android.Helper;

namespace Cobalt.Android.Activites
{
    //[Activity(Label = "CobieWbviewActivity")]
    [Activity(Label = "CobieWbviewActivity", ScreenOrientation = ScreenOrientation.Portrait)]
    public class CobieWbviewActivity : Activity
    {
        public WebView mWebView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.ChatWebviewlayout);
            var selectedItemId = Intent.Extras.GetString("weburi");
            mWebView = FindViewById<WebView>(Resource.Id.webView);
            mWebView.Settings.JavaScriptEnabled = true;
            mWebView.Settings.SetPluginState(WebSettings.PluginState.On);
            mWebView.SetWebViewClient(new MyWebViewClient(this));

            string URI = Constants.CHATBOTWEBVIEW + AppSharedPreferencesSingleton.GetInstance().getAccessKey("token");
            //Load url to be randered on WebView
            mWebView.LoadUrl(selectedItemId.ToString());

            // Create your application here
        }
    }
}