using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Widget;
using Cobalt.Android.Helper;
using Android.Util;
using System.Threading.Tasks;
using Cobalt.Android.Utils;
using Android.Content.PM;
using Android.App;
using Android.OS;
using System.IO;
using static Android.App.ActionBar;
using Newtonsoft.Json;
using Android.Text;
using Android.Content;
using Android.Views;
using Cobalt.Android.Fragments;

namespace Cobalt.Android.Activites
{
    // [Activity(Label = "SendSMSActivity")]

    [Activity(Label = "SendSMSActivity", ScreenOrientation = ScreenOrientation.Portrait)]
    public class SendSMSActivity : AppComCustomeActivty
    {
        public static  string INTENT_PHONENUMBER = "phonenumber";
        public static  string INTENT_COUNTRY_CODE = "code";

        private EditText mPhoneNumber;
        private Button mSmsButton;
   
        Com.Hbb20.CountryCodePicker ccp;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.SendSMSlayout);

            LinearLayout linearlayout = (LinearLayout)FindViewById(Resource.Id.linearlayout);
            ccp = new Com.Hbb20.CountryCodePicker(this);
            if (ccp != null)
            {
                LayoutParams LayoutParams = new LayoutParams(LayoutParams.MatchParent, LayoutParams.MatchParent);
                ccp.SetCountryForNameCode("US");
                ccp.ShowFullName(true);
                ccp.SetHorizontalGravity(GravityFlags.CenterHorizontal);
                ccp.SetTextSize(26);
                ccp.LayoutParameters = LayoutParams;
                linearlayout.AddView(ccp);

            }
            mPhoneNumber = (EditText)FindViewById(Resource.Id.phoneNumber);
            mSmsButton = (Button)FindViewById(Resource.Id.smsVerificationButton);
            mSmsButton.Click += MSmsButton_Click;
            // Create your application here
        }

      
        private void MSmsButton_Click(object sender, EventArgs e)
        {
            try
            {
                //
                if (!validate())
                    return;


                ShowForgotPsswordDia();
                //StartActivity(new Intent(Application.Context, typeof(ValidationKey)));

            }
            catch (Exception ex)
            {

            }
        }

        public void ShowForgotPsswordDia()
        {
            try
            {
                FragmentTransaction fragmentTransaction = FragmentManager.BeginTransaction();
                //remove fragment from backstack if any exists
                Fragment fragmentPrev = FragmentManager.FindFragmentByTag("dialog");
                if (fragmentPrev != null)
                    fragmentTransaction.Remove(fragmentPrev);

                fragmentTransaction.AddToBackStack(null);
                //create and show the dialog
                DialogFragmentSample dialogFragment = DialogFragmentSample.NewInstace(null);
                dialogFragment.Show(fragmentTransaction, "dialog");
            }
            catch(Exception ex)
            {

            }
        }

        public bool validate()
        {
            bool valid = true;

            string email = mPhoneNumber.Text.ToString();
          

            if (string.IsNullOrEmpty(email) )
            {
                mPhoneNumber.Error = GetString(Resource.String.enterphonenumber);
                valid = false;
            }
            else
            {
                mPhoneNumber.Error = null;
            }
            return valid;
        }

   
    }
}