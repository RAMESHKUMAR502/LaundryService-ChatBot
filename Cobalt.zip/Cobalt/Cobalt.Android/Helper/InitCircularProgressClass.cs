﻿using Android.Widget;
using Android.Content;
using Android.Views;
using Android.Graphics;
using Android.Util;

namespace Cobalt.Android.Helper
{
	public class InitCircularProgressClass :FrameLayout,CircularProgressBarClass.IOnProgressChangeListener
	{
		CircularProgressBarClass mCircularProgressBar;
		TextView mRateText;
        TextView mLaodingText;
		int maxValue;
		public InitCircularProgressClass(Context context):base(context) { 
			init();
		}
		public InitCircularProgressClass(Context context, IAttributeSet attrs) :base(context,attrs){ 
			init();
		}
		void init() {
			mCircularProgressBar = new CircularProgressBarClass( Context);
			AddView(mCircularProgressBar);
			var lp = new LayoutParams(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.MatchParent);
			lp.Gravity = GravityFlags.Center;
           
			mCircularProgressBar.LayoutParameters=lp;
			mRateText = new TextView(Context);
			AddView(mRateText);
			mRateText.LayoutParameters=lp;
           // mRateText.SetPadding(0, 5, 0, 0);

            mRateText.Gravity=GravityFlags.Center;

            mLaodingText = new TextView(Context);
            AddView(mLaodingText);

            var lptxt = new LayoutParams(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.MatchParent);
            lptxt.Gravity = GravityFlags.Center;
            lptxt.SetMargins(0, 8, 0, 0);
            mLaodingText.LayoutParameters = lptxt;
            mLaodingText.SetTextColor(Color.DarkGray);
            mLaodingText.Text = "Loading..";
            mLaodingText.SetTextSize(ComplexUnitType.Dip,16);
            mLaodingText.SetPadding(0,58,0,0);
           mLaodingText.Gravity = GravityFlags.Center;

            mCircularProgressBar.setOnProgressChangeListener(this);
		}
		public void setMax( int max ) {
			mCircularProgressBar.setMax(max);
			maxValue = max;
		}

		public void setProgress(int progress) {
			mCircularProgressBar.setProgress(progress);
		}

		public CircularProgressBarClass getCircularProgressBar() {
			return mCircularProgressBar;
		}

		public void setTextSize(float size) {
			mRateText.SetTextSize(ComplexUnitType.Dip,size);
		}

		public void setTextColor( Color color) {
			mRateText.SetTextColor(color); 
		} 

		public void setTextTypeFaceBold()
		{
			mRateText.Typeface = Typeface.Default;
		}
			
		public void onChange(int duration, int progress, float rate)
		{ 
			mRateText.Text=( (int) (rate * maxValue )).ToString() + "%";    
		}
 
	}
}

