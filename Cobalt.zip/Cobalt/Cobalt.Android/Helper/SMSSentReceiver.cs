using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Telephony;

namespace Cobalt.Android.Helper
{
    [BroadcastReceiver(Exported = true, Permission = "//receiver/@android:android.permission.SEND_SMS")]
    public class SMSSentReceiver : BroadcastReceiver
    {
        public override void OnReceive(Context context, Intent intent)
        {
            switch ((int)ResultCode)
            {
                case (int)Result.Ok:
                    Toast.MakeText(Application.Context, "SMS has been sent", ToastLength.Short).Show();
                    break;
                case (int)SmsResultError.GenericFailure:
                    Toast.MakeText(Application.Context, "Generic Failure", ToastLength.Short).Show();
                    break;
                case (int)SmsResultError.NoService:
                    Toast.MakeText(Application.Context, "No Service", ToastLength.Short).Show();
                    break;
                case (int)SmsResultError.NullPdu:
                    Toast.MakeText(Application.Context, "Null PDU", ToastLength.Short).Show();
                    break;
                case (int)SmsResultError.RadioOff:
                    Toast.MakeText(Application.Context, "Radio Off", ToastLength.Short).Show();
                    break;
            }
        }
    }

    [BroadcastReceiver(Exported = true, Permission = "//receiver/@android:android.permission.SEND_SMS")]
    public class SMSDeliveredReceiver : BroadcastReceiver
    {
        public override void OnReceive(Context context, Intent intent)
        {
            switch ((int)ResultCode)
            {
                case (int)Result.Ok:
                    Toast.MakeText(Application.Context, "SMS Delivered", ToastLength.Short).Show();
                    break;
                case (int)Result.Canceled:
                    Toast.MakeText(Application.Context, "SMS not delivered", ToastLength.Short).Show();
                    break;
            }
        }
    }



    public class SendTelSMS
    {
        SmsManager _smsManager;
        BroadcastReceiver _smsSentBroadcastReceiver, _smsDeliveredBroadcastReceiver;
       
        public void Init()
        {
            _smsManager = SmsManager.Default;
        }
        public void SendSMS(Context aCntex,string aPhnNumber, string aMessage)
        {
            try
            {
                var piSent = PendingIntent.GetBroadcast(aCntex, 0, new Intent("SMS_SENT"), 0);
                var piDelivered = PendingIntent.GetBroadcast(aCntex, 0, new Intent("SMS_DELIVERED"), 0);

                _smsManager.SendTextMessage(aPhnNumber, null, aMessage, piSent, piDelivered);
            }
            catch(Exception ex)
            {

            }
        }


        public void InitBroadCast(Context aCont)
        {
            try
            {
                _smsSentBroadcastReceiver = new SMSSentReceiver();
                _smsDeliveredBroadcastReceiver = new SMSDeliveredReceiver();

                aCont.RegisterReceiver(_smsSentBroadcastReceiver, new IntentFilter("SMS_SENT"));
                aCont.RegisterReceiver(_smsDeliveredBroadcastReceiver, new IntentFilter("SMS_DELIVERED"));
            }
            catch(Exception ex)
            {

            }
        }

        public void Unregister(Context aCont)
        {
            try
            {
                aCont.UnregisterReceiver(_smsSentBroadcastReceiver);
                aCont. UnregisterReceiver(_smsDeliveredBroadcastReceiver);
            }
            catch(Exception ex)
            {

            }
        }
    }
}