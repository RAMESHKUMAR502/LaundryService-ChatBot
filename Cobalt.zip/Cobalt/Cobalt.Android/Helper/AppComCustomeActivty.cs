using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Calligraphy;

namespace Cobalt.Android.Helper
{
    public class AppComCustomeActivty : AppCompatActivity
    {
        AlertDialog dialog;

        protected override void AttachBaseContext(Context newBase)
        {
            base.AttachBaseContext(CalligraphyContextWrapper.Wrap(newBase));
        }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            //CalligraphyConfig.InitDefault(new CalligraphyConfig.Builder()
            // .SetDefaultFontPath("Fonts/Avenir.ttc")
            // .SetFontAttrId(Resource.Attribute.fontPath)
            // .Build());
            //dialog = CustomDialog.initializeDialog(this);
        }


        public void disposeCustomDialog()
        {
            dialog.Dismiss();
        }

        public void showCustomDialog()
        {
            if (dialog.IsShowing != true)
            {
                dialog.SetCancelable(false);
                dialog.Show();
            }
        }
    }
}