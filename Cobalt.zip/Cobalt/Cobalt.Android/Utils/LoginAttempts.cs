using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;

namespace Cobalt.Android.Utils
{
    public class LoginAttempts
    {
        private static LoginAttempts _instance;

        private LoginAttempts()
        {
            // Constructor hidden because this is a singleton
        }
        // Constructor is 'protected'

        public static LoginAttempts GetInstance()
        {
            // Uses lazy initialization.
            // Note: this is not thread safe.
            if (_instance == null)
            {
                _instance = new LoginAttempts();

            }

            return _instance;
        }

        public void SaveLoginFaliedAttemps()
        {
            try
            {
                 if (string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("LoginAttepmt")))
                    {
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("LoginAttepmt",Convert.ToString(1));
                    }
                else
                {
                    int loginAttmete = Convert.ToInt16(AppSharedPreferencesSingleton.GetInstance().getAccessKey("LoginAttepmt"));
                    loginAttmete = loginAttmete + 1;
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("LoginAttepmt", Convert.ToString(loginAttmete));

                }

            }
            catch(Exception ex)
            {

            }

        }

        public void RemoveLoginAttempts()
        {
            try
            {
                AppSharedPreferencesSingleton.GetInstance().RemoveTheItem("LoginAttepmt");
            }
            catch (Exception ex)
            {

            }

        }

        public bool isAccountLocked()
        {
            try
            {
                if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("LoginAttepmt")))
                {
                    int loginAttmete = Convert.ToInt16(AppSharedPreferencesSingleton.GetInstance().getAccessKey("LoginAttepmt"));

                    if(loginAttmete >= Constants.LOGIN_ATTEMPT)
                    {
                        return true;
                    }
                }
             }
            catch (Exception ex)
            {

            }

            return false;

        }

        public int GetLoginAttemps()
        {

            return 0;
        }
    }
}