using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;
using Cobalt.Android.Activites;
using Cobalt.Android.Fragments;

namespace Cobalt.Android.Services
{
    public class LoginFlowService
    {
        private static LoginFlowService _instance;

        private LoginFlowService()
        {
            // Constructor hidden because this is a singleton
        }
        // Constructor is 'protected'

        public static LoginFlowService GetInstance()
        {
            // Uses lazy initialization.
            // Note: this is not thread safe.
            if (_instance == null)
            {
                _instance = new LoginFlowService();

            }

            return _instance;
        }

        //Flow One....
        /// <summary>
        /// If new User there is No USERID and dEvoce ID--Show Provision Screen..
        /// If device ID and User Exits But there also Some Car exits Then...New Flow..
        /// </summary>
        /// <param name="aUserId"></param>
        /// <param name="aDeviceID"></param>
        /// <returns></returns>

        public bool isUserIdDevceIdExits(string aUserId,string aDeviceID)
        {
            bool isExits = false;
            try
            {
                string UserId = null;
                string devcieID = null;
                if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UserId")))
                {
                    UserId = AppSharedPreferencesSingleton.GetInstance().getAccessKey("UserId");
                }
               else
                {
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("UserId", aUserId);
                }

                if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("DeviceID")))
                {
                    devcieID = AppSharedPreferencesSingleton.GetInstance().getAccessKey("DeviceID");
                }
                else
                {
                    AppSharedPreferencesSingleton.GetInstance().saveAccessKey("DeviceID", aDeviceID);
                }

                if (UserId != null && devcieID != null)
                {
                    if(UserId.Equals(aUserId) && devcieID.Equals(aDeviceID))
                    {
                        isExits = true;
                    }
                    else
                        isExits = false;
                }
                else
                    isExits = false;

            }
            catch (Exception ex)
            {

            }

            return isExits;

        }

        /// <summary>
        /// if No provisonalVechial Exits Show Provinsal Screen
        /// if false then ShowProvisonal Screen
        /// if true..Show the Dialog "Unresigetr the Cobalt from Other devcie Yes"
        /// </summary>
        /// <returns></returns>
        public bool IsprovisonalVechialExits()
        {
            bool isprovVeExits = false;

            return isprovVeExits;
        }

    }
}