﻿using System;
using System.Threading.Tasks;
using Cobalt.Models;
using PCLCrypto;
using System.Text;


namespace Cobalt.Common
{
    public class Core
    {
        /// <summary>
        /// HOST_NAME - This is Front End API Base URL.
        /// </summary>
        public const string HOST_NAME = "http://cobalt-fe-api-dev.azurewebsites.net/api/v1";
        private const string secretKey = "093f08db-bf72-467c-bb76-c088bf04e9ad";

        /// <summary>
        /// AuthenticateUser - Authenticates User and returns user profile
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static async Task<User> AuthenticateUser(User user)
        {
            string loginURL = HOST_NAME + "/user/login";
            string requestBodyContent = "{\"email\":\"" + user.email + "\",\"password\":\"" + user.password + "\"}";
            var results = await DataService.PostDataToService(loginURL, requestBodyContent).ConfigureAwait(false);
            int status = results != null ? (int)results["status"] : 500;
            User _loggedinUser = new User();
            _loggedinUser.status = status;

			switch(status) {
   				case 200  :
      				_loggedinUser.userToken = (string)results["token"];
		            _loggedinUser.userid = (string)results["user"]["id"];
                    _loggedinUser.firstName = (string)results["user"]["profile"]["FirstName"];
                    _loggedinUser.surname = (string)results["user"]["profile"]["SurName"];
                    _loggedinUser.loginAttempt = (string)results["user"]["profile"]["LoginAttempt"];
                    _loggedinUser.uniqueDeviceId = (string)results["user"]["profile"]["UniqueDeviceId"];
                    _loggedinUser.isActive = (string)results["user"]["profile"]["isActive"];
                      break; 
				case 402  :
   				case 401  :
					_loggedinUser.message=(string)results["user"]["message"];
					
	      			break;
   				default : 
   					_loggedinUser.message="internal error";
					break;
			}
		

            return _loggedinUser;
        }
        
        /// <summary>
        ///  Login - Log in User (Signin)
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static async Task<LoggedInUser> Login(User user)
        {
            string loginURL = HOST_NAME + "/user/login";
            string requestBodyContent = "{\"email\":\"" + user.email + "\",\"password\":\"" + user.password + "\"}";
            var results = await DataService.PostDataToService(loginURL, requestBodyContent).ConfigureAwait(false);

            if (results != null)
            {
                LoggedInUser _loggedinUser = new LoggedInUser();
                _loggedinUser.token = (string)results["token"];
                return _loggedinUser;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Register - Signup a new User
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static async Task<User> Register(User user)
        {
            string registerURL = HOST_NAME + "/user/signup";
            string requestBodyContent = "{\"firstname\":\"" + user.firstName + "\",\"surname\":\"" + user.surname + "\",\"email\":\"" + user.email + "\",\"password\":\"" + user.password + "\"}";
            var results = await DataService.PostDataToService(registerURL, requestBodyContent).ConfigureAwait(false);
            User _newUser = new User();
            if (results != null)
            {

                _newUser.userid = (string)results["id"];

                LoggedInUser _User = await Core.Login(user);
                if (_User != null) //Successfully Logged in
                {
                    string token = _User.token;
                    _newUser.userToken = token;
                    _newUser.uniqueDeviceId = user.uniqueDeviceId;
                    User _userProfile = await Core.CreateProfile(user, token);

                }

                return _newUser;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// CreateProfile - Creates User Profile
        /// </summary>
        /// <param name="user"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public static async Task<User> CreateProfile(User user, string token)
        {
            string registerURL = HOST_NAME + "/user/profile";
            string requestBodyContent = "{\"FirstName\":\"" + user.firstName + "\",\"SurName\":\"" + user.surname + "\",\"UniqueDeviceId\":\"" + user.uniqueDeviceId + "\",\"isActive\":\"" + user.isActive + "\",\"LoginAttempt\":\"" + user.loginAttempt + "\"}";
            var results = await DataService.PostDataToService(registerURL, requestBodyContent, token).ConfigureAwait(false);

            if (results != null)
            {
                User _newUser = new User();
                _newUser.userid = (string)results["id"];
                return _newUser;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// GetDeviceId - Return Unqiue GUID  
        /// As Android returns proper UDID for a Device but not iOS
        /// So we are using .net based unique GUID approach.
        /// </summary>
        /// <returns></returns>
        public static string GetDeviceId()
        {
            try
            {
                return Guid.NewGuid().ToString();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// ValidateDevice - Validates DeviceId (Stored in Documentdb and local store)
        /// </summary>
        /// <param name="lsDeviceId">lsDeviceId - DeviceId stored in local store</param>
        /// <param name="sDeviceId">sDeviceId - DeviceId stored in Documentdb</param>
        /// <returns></returns>
        public static bool ValidateDevice(string lsDeviceId, string sDeviceId)
        {
            bool isValidDevice = false;
            lsDeviceId = lsDeviceId.ToLower().Trim();
            sDeviceId = sDeviceId.ToLower().Trim();
            if (lsDeviceId == sDeviceId)
            {
                isValidDevice = true;
            }

            return isValidDevice;
        }

        /// <summary>
        /// Creates Salt with given length in bytes
        /// </summary>
        /// <param name="lengthInBytes"></param>
        /// <returns></returns>
        public static byte[] CreateSalt(int lengthInBytes)
        {
            return WinRTCrypto.CryptographicBuffer.GenerateRandom(lengthInBytes);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="salt"></param>
        /// <param name="keyLengthInBytes"></param>
        /// <param name="iterations"></param>
        /// <returns></returns>
        public static byte[] CreateDerivedKey(string password, byte[] salt, int keyLengthInBytes = 32, int iterations = 1000)
        {
            byte[] key = NetFxCrypto.DeriveBytes.GetBytes(password, salt, iterations, keyLengthInBytes);
            return key;
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="data"></param>
       /// <returns></returns>
        public static byte[] EncryptData(string data)
        {
            var salt = Core.CreateSalt(16);
            byte[] key = CreateDerivedKey(secretKey, salt);

            ISymmetricKeyAlgorithmProvider aes = WinRTCrypto.SymmetricKeyAlgorithmProvider.OpenAlgorithm(SymmetricAlgorithm.AesCbcPkcs7);
            ICryptographicKey symetricKey = aes.CreateSymmetricKey(key);
            var bytes = WinRTCrypto.CryptographicEngine.Encrypt(symetricKey, Encoding.UTF8.GetBytes(data));

            return bytes;
            //string enCryptedString = Convert.ToBase64String(bytes);
            //enCryptedString = Convert.ToBase64String(bytes) + ";" + Convert.ToBase64String(key);
            //return enCryptedString;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static string DecryptData(byte[] data)
        {
           // byte[] brData = Encoding.UTF8.GetBytes(data);

            var salt = Core.CreateSalt(16);
            byte[] key = CreateDerivedKey(secretKey, salt);

            ISymmetricKeyAlgorithmProvider aes = WinRTCrypto.SymmetricKeyAlgorithmProvider.OpenAlgorithm(SymmetricAlgorithm.AesCbcPkcs7);
            ICryptographicKey symetricKey = aes.CreateSymmetricKey(key);
            var bytes = WinRTCrypto.CryptographicEngine.Decrypt(symetricKey, data);
            return Encoding.UTF8.GetString(bytes, 0, bytes.Length);
        }

    }
}