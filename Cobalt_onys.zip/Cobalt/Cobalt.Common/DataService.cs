﻿using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Text;
using System.Net.Http.Headers;
using System;

namespace Cobalt.Common
{
    /// <summary>
    /// DataService - This class will have code related to API calls
    /// </summary>
    public class DataService
    {

        /// <summary>
        /// GetDataFromService - Get (httpGet) data from API
        /// </summary>
        /// <param name="queryString">queryString - parameter</param>
        /// <returns></returns>
        public static async Task<JContainer> GetDataFromService(string queryString)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetAsync(queryString);

            JContainer data = null;
            if (response != null)
            {
                string json = response.Content.ReadAsStringAsync().Result;
                data = (JContainer)JsonConvert.DeserializeObject(json);
            }

            return data;
        }

        /// <summary>
        /// PostDataToService - Post (httpPost) data to Service
        /// </summary>
        /// <param name="requestURL">requestURL - Service API URL</param>
        /// <param name="bodyContent">bodyContent - Body Content which is posted to API</param>
        /// <returns></returns>
        public static async Task<JContainer> PostDataToService(string requestURL, string bodyContent)
        {
			try
			{
				HttpContent requestContent = new StringContent(bodyContent, Encoding.UTF8, "application/json");
				HttpClient client = new HttpClient();
                //client.Timeout = System.TimeSpan.FromSeconds(30);
                var response = await client.PostAsync(requestURL, requestContent);

				JContainer data = null;
				if (response != null)
				{
					string json = response.Content.ReadAsStringAsync().Result;
					data = (JContainer)JsonConvert.DeserializeObject(json);
				}

				return data;
			}
			catch (Exception ex)
			{
				return null;
			}

        }

        /// <summary>
        /// PostDataToService - Post (httpPost) data to Service
        /// </summary>
        /// <param name="requestURL">requestURL - Service API URL</param>
        /// <param name="bodyContent">bodyContent - Body Content which is posted to API</param>
        /// <param name="authToken">authToken - Auth Token which is passed to Service call as Bearer Token in AuthenticationHeaderValue</param>
        /// <returns></returns>
        public static async Task<JContainer> PostDataToService(string requestURL, string bodyContent, string authToken)
        {

            HttpContent requestContent = new StringContent(bodyContent, Encoding.UTF8, "application/json");
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);

            var response = await client.PostAsync(requestURL, requestContent);

            JContainer data = null;
            if (response != null)
            {
                string json = response.Content.ReadAsStringAsync().Result;
                data = (JContainer)JsonConvert.DeserializeObject(json);
            }

            return data;
        }

    }
}