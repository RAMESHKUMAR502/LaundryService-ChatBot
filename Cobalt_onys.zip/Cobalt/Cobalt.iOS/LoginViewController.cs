using Foundation;
using System;
using UIKit;
using Cobalt.Common;
using Cobalt.Models;
using LocalAuthentication;
namespace Cobalt.iOS
{
    public partial class LoginViewController : UIViewController
    {
		
		LAContext context = new LAContext();
		LoadingOverlay loadingOverlay;
		NSError error;
        public LoginViewController (IntPtr handle) : base (handle)
        {
        }
		public override void ViewDidLoad()
		{
			base.ViewDidLoad();

			txtUserName.Placeholder = "Username";
			txtPassword.Placeholder = "Password";

			LoginButton.TouchUpInside += Button_Click;
			//loginActivity.Hidden = true;

			btnHelp.TouchUpInside += Help_Click;

			btnFingerPrint.Hidden = true;

			if (context.CanEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, out error))
				btnFingerPrint.Hidden = false;
			btnFingerPrint.TouchUpInside += BtnFingerPrint_Click;
		}


		public override void ViewDidAppear(bool animated)
		{
			base.ViewDidAppear(animated);
			txtUserName.Text = KeychainHelpers.UserName;
			//txtPassword.Text = KeychainHelpers.Password;
		}



		private async void Help_Click(object sender, EventArgs e)
		{
			var cobbiController = Utility.GetViewController(Utility.MainStoryboard, "CobbiViewController") as CobbiViewController;
			cobbiController.SourceControll = this;
			cobbiController.ScreenName = "login";
			Utility.SetRootViewController(cobbiController, this, true);

		}

		private async void BtnFingerPrint_Click(object sender, EventArgs e)
		{
			
			if (context.CanEvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, out error))
			{
				var replyHandler = new LAContextReplyHandler((success, error) =>
					{
						InvokeOnMainThread(() =>
							{
								if (success)
								{
                                    Call_Login(KeychainHelpers.UserName, KeychainHelpers.Password);
								}
								else
								{
									var alert = new UIAlertView("OOPS!", "Something went wrong.", null, "Oops", null);
									alert.Show();
								}
							});
					});
				context.EvaluatePolicy(LAPolicy.DeviceOwnerAuthenticationWithBiometrics, "Logging in with Touch ID", replyHandler);
			}
			else
			{
				var alert = new UIAlertView("Error", "TouchID not available", null, "BOOO!", null);
				alert.Show();
			}
		}
		private async void Button_Click(object sender, EventArgs e)
		{
			txtPassword.Text = "Admin@1234";
			string username = txtUserName.Text;
			string password = txtPassword.Text;
			Call_Login(username,password);
		}
		private async void Call_Login(string username,string password )
		{


			if (string.IsNullOrEmpty(username.Trim()))
			{
				Utility.Show_Alert("Username Name cannot be empty. Please enter a valid name.");
				return;
			}

			if (string.IsNullOrEmpty(password.Trim()))
			{
				Utility.Show_Alert("Password cannot be empty. Please enter a valid name.");
				return;
			}
			var bounds = UIScreen.MainScreen.Bounds;

			// show the loading overlay on the UI thread using the correct orientation sizing
			loadingOverlay = new LoadingOverlay(bounds);
			View.Add (loadingOverlay);
			LoginButton.Enabled = false;

            User _user = new User();
            _user.email = username;
            _user.password = password;
            User _User = await Core.AuthenticateUser(_user); //Pass UserName and password from Login Screen
			int status = _User.status;
			loadingOverlay.Hide ();
			switch(status) { //Successfully Logged i
   				case 200  :
					string LoggedinUserToken = _User.userToken;
					_User.password = password;
					if (_User.uniqueDeviceId == KeychainHelpers.DeviceId)
					{
						var cobbiController = Utility.GetViewController(Utility.MainStoryboard, "CobbiViewController") as CobbiViewController;
						cobbiController.Tocken = LoggedinUserToken;
						cobbiController.SourceControll = this;
						Utility.SetRootViewController(cobbiController, this, true);
					}
					else
					{
						var mobileRegistratiionViewController = Utility.GetViewController(Utility.MainStoryboard, "MobileRegistrationController") as MobileRegistrationController;
						Utility.SetRootViewController(mobileRegistratiionViewController, this, true);

					}
      				break;
   				default : 
   					Utility.Show_Alert(_User.message);
					break;
			}


		
			LoginButton.Enabled = true;
			loadingOverlay.Hide ();

		}


	}
}