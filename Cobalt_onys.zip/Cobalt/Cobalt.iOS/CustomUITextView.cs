using Foundation;
using System;
using UIKit;

namespace Cobalt.iOS
{
	public partial class CustomUITextView : UITextField
	{
		public UILabel ErrorLable;
		public string ErrorMessage;
		public CustomUITextView CompareTextField;
		public Action<object, EventArgs> Cb;
		public CustomUITextView(IntPtr handle) : base(handle)
		{
		}
	}
}