﻿using System;
using System.Linq;
using Cobalt.Models;
using Xamarin.Auth;
namespace Cobalt.iOS
{
	public class KeychainHelpers
	{

		public KeychainHelpers()
		{

		}
		public static void SaveCredentials(User user)
		{
			try
			{
				string userName = user.email;
				string password = user.password;
				string deviceId = user.uniqueDeviceId;
				if (!string.IsNullOrWhiteSpace(userName) && !string.IsNullOrWhiteSpace(password))
				{
					AccontKey = "Cobalt_App";
					Account account = new Account
					{
						Username = userName
					};
					account.Properties.Add("Password", password);
					account.Properties.Add("DevieId", deviceId);
					AccountStore.Create().Save(account, AccontKey);
				}
			}
			catch (Exception ex)
			{
			}

		}
		public static string AccontKey { set; get; }
		public static string UserName
		{
			get
			{
				try
				{
					AccontKey = "Cobalt_App" ;
					var account = AccountStore.Create().FindAccountsForService(AccontKey).FirstOrDefault();
					return (account != null) ? account.Username : null;
				}
				catch (Exception ex)
				{
					return null;
				}
			}
		}

		public static string Password
		{
			get
			{
				try
				{
					AccontKey = "Cobalt_App" ;
					var account = AccountStore.Create().FindAccountsForService(AccontKey).FirstOrDefault();
					return (account != null) ? account.Properties["Password"] : null;
				}
				catch (Exception ex)
				{
					return null;
				}
			}
		}
		public static string DeviceId
		{
			get
			{
				try
				{
					AccontKey = "Cobalt_App" ;
					var account = AccountStore.Create().FindAccountsForService(AccontKey).FirstOrDefault();
					return (account != null) ? account.Properties["DevieId"] : null;
				}
				catch (Exception ex)
				{
					return null;
				}
			}
		}


		public static void DeleteCredentials()
		{
			try
			{
				AccontKey = "Cobalt_App" ;
				var account = AccountStore.Create().FindAccountsForService(AccontKey).FirstOrDefault();
				if (account != null)
				{
					AccountStore.Create().Delete(account, AccontKey);
				}
			}
			catch (Exception ex)
			{
				
			}
		}

	}
}
