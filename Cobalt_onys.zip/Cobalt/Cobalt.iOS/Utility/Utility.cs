﻿using System;
using Foundation;
using UIKit;

namespace Cobalt.iOS
{
	public class Utility
	{
		public Utility()
		{
		}

		public static void ConfigureCoustomTesxtViw(CustomUITextView textView,
													UILabel lblError, string errorMessage, 
		                                            Action<object, EventArgs> cb = null,
													CustomUITextView CompareTextView = null)
		{
			textView.ErrorLable = lblError;
			textView.ErrorMessage = errorMessage;
			textView.CompareTextField = CompareTextView;
			textView.ShouldReturn += (textField) =>
			{
				textField.ResignFirstResponder();
				return true;
			};
			if (cb != null) textView.Cb = cb;
		}
		public static UIViewController GetViewController(UIStoryboard storyboard, string viewControllerName)
		{
			return storyboard.InstantiateViewController(viewControllerName);
		}
		public static void SetRootViewController(UIViewController rootViewController, UIViewController baseController,bool animate)
		{
			baseController.View.Window.RootViewController = rootViewController;
		}
		public static UIStoryboard MainStoryboard
		{
			get { return UIStoryboard.FromName("Main", NSBundle.MainBundle); }
		}
		public static void Show_Alert(string msg)
		{
			UIAlertView alert = new UIAlertView()
			{
				Title = "Error",
				Message = msg
			};
			alert.AddButton("OK");
			alert.Show();
		}
	}
}
