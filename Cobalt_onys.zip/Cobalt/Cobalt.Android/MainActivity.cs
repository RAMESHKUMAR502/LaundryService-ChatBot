﻿using System;
using Android.App;
using Android.Widget;
using Android.OS;
using Cobalt.Android.Helper;
using Android.Content.PM;

namespace com.jccbowers.cobalt
{
    [Activity(ScreenOrientation = ScreenOrientation.Portrait)]
    public class MainActivity : AppComCustomeActivty
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            // SetContentView (Resource.Layout.Main);
        }
    }
}

