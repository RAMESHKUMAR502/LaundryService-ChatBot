using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Preferences;
using Android.Util;

namespace Cobalt.Android.Helper
{
   public class AppSharedPreferencesSingleton
    {
        private ISharedPreferences mSharedPrefs;
        private ISharedPreferencesEditor mPrefsEditor;
        private Context mContext;

        private static AppSharedPreferencesSingleton _instance;

        private AppSharedPreferencesSingleton()
        {
            // Constructor hidden because this is a singleton
        }
        // Constructor is 'protected'
       
        public static AppSharedPreferencesSingleton GetInstance()
        {
            // Uses lazy initialization.
            // Note: this is not thread safe.
            if (_instance == null)
            {
                _instance = new AppSharedPreferencesSingleton();
               
            }

            return _instance;
        }
        public void Init()
        {
            try
            {
                if (mSharedPrefs == null)
                {
                    mSharedPrefs = PreferenceManager.GetDefaultSharedPreferences(Application.Context);
                    mPrefsEditor = mSharedPrefs.Edit();
                }
            }
            catch(Exception ex)
            {

            }
       }

        public void saveAccessKey(string key,string aValue)
        {
            try
            {
                Init();
                mPrefsEditor.PutString(key, aValue);
               
                mPrefsEditor.Commit();
            }
            catch(Exception ex)
            {

            }
          
        }

        public void RemoveTheItem(string aKey)
        {
            try
            {
                Init();
                mPrefsEditor.Remove(aKey);

                mPrefsEditor.Commit();
            }
            catch(Exception ex)
            {

            }
        }

        public string getAccessKey(string aKey)
        {
            try
            {
                Init();
                return mSharedPrefs.GetString(aKey, "");
            }
            catch(Exception ex)
            {
                return null;    
            }
        }

        public string encrypt(string input)
        {
            // Simple encryption, not very strong!
            return Base64.EncodeToString(GetBytes(input), Base64.Default);
        }


            
        byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        string GetString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }

        public string decrypt(string input)
        {
            return GetString(Base64.Decode(Encoding.ASCII.GetBytes(input), Base64.Default));
        }
    }
}