using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Graphics;

namespace Cobalt.Android.Helper
{
   public class ClassMenu : View
    {
        private Paint mainPaint;
        private Paint secondPaint;
        private Paint textPaint;
        private int radius_main = 5;

        private int menuInnerPadding = 40;
        private int radialCircleRadius = 90;
        private int textPadding = 25;
        private double startAngle = -Math.PI / 2f;
        private List<MenuCircle> elements;
        private IMenuListener listener;

        public void setListener(IMenuListener listener)
        {
            this.listener = listener;
        }

        public ClassMenu(Context context) : base(context)
        {
            Init();
        }

        public ClassMenu(Context context, IAttributeSet attrs) : base(context, attrs)
        {
            Init();
        }

        public ClassMenu(Context context, IAttributeSet attrs, int defStyleAttr) : base(context, attrs, defStyleAttr)
        {
            Init();
        }

        public ClassMenu(Context context, IAttributeSet attrs, int defStyleAttr, int defStyleRes) : base(context, attrs, defStyleAttr, defStyleRes)
        {
            Init();
        }

        protected ClassMenu(IntPtr javaReference, JniHandleOwnership transfer) : base(javaReference, transfer)
        {
            Init();
        }

        public void clear()
        {
            if (elements != null)
            {
                elements.Clear();
            }
            
        }
        public void Init()
        {
            elements = new List<MenuCircle>();
        }
        public void addMenuItem(String text, int id,int ResorceId)
        {
            MenuCircle item = new MenuCircle();
            item.id = id;
            item.text = text;
            item.Imglink = BitmapFactory.DecodeResource(Resources,ResorceId);
            elements.Add(item);

        }

        protected override void OnDraw(Canvas canvas)
        {
            int centerX = canvas.Width/ 2;
            int centerY = canvas.Height / 2;
            int width = canvas.Width;
            int height = canvas.Height;
            // canvas.DrawCircle(centerX, centerY, radius_main, mainPaint);
            for (int i = 0; i < elements.Count(); i++)
            {
                double angle = 0;
                if (i == 0)
                {
                    angle = startAngle;
                }
                else
                {
                    angle = startAngle + (i * ((2 * Math.PI) / elements.Count()));
                }
                elements[i].x = (int)(centerX + Math.Cos(angle) * (radius_main + menuInnerPadding + radialCircleRadius));
                elements[i].y = (int)(centerY + Math.Sin(angle) * (radius_main + menuInnerPadding + radialCircleRadius));


                canvas.DrawCircle(elements[i].x, elements[i].y, radialCircleRadius, secondPaint);


                //int centerX = (int)((mOuterRadius + mInnerRadius) / 2 * Java.Lang.Math.Cos(Java.Lang.Math.ToRadians(startAngle + mSweepAngle / 2)));
                //int centerY = (int)((mOuterRadius + mInnerRadius) / 2 * Java.Lang.Math.Sin(Java.Lang.Math.ToRadians(startAngle + mSweepAngle / 2)));

                canvas.DrawBitmap(elements[i].Imglink, elements[i].x - elements[i].Imglink.Width/2, elements[i].y - elements[i].Imglink.Height/2 - 10, null);

                float tW = textPaint.MeasureText(elements[i].text);
                textPaint.TextSize = 24.0f;
                canvas.DrawText(elements[i].text, elements[i].x - tW / 2, elements[i].y + radialCircleRadius-20, textPaint);
            }

            base.OnDraw(canvas);
        }
        protected override void OnFinishInflate()
        {
            try
            {
                mainPaint = new Paint();
                mainPaint.Color = Color.Blue;
                secondPaint = new Paint();
                secondPaint.Color = Color.ParseColor("#ADD8E6");
                textPaint = new Paint();
                textPaint.Color = Color.White;
            }
            catch(Exception ex)
            {

            }
            base.OnFinishInflate();
        }

        public override bool OnTouchEvent(MotionEvent e)
        {
            try
            {

                if (e.Action == MotionEventActions.Down)
                {
                    foreach (MenuCircle mc in elements)
                    {
                        double distance = Math.Pow(e.GetX() - mc.x, e.GetY() - mc.y);
                        if (distance <= radialCircleRadius)
                        {
                            //touched
                            if (listener != null)
                                listener.onMenuClick(mc);

                            return true;
                        }

                    }
                }
            }
            catch (Exception ex)
            {

            }

            return base.OnTouchEvent(e);
        }

        public interface IMenuListener
        {
            void onMenuClick(MenuCircle item);
        }
        public Bitmap CreateBimap(int id)
        {
            int iW = 80;
            int iH = 80;
            Bitmap mOriginalBitmap;
            BitmapFactory.Options options = new BitmapFactory.Options();
            //Load image from resource
            mOriginalBitmap = BitmapFactory.DecodeResource(Resources, Id,options);
            //Scale to target size
            mOriginalBitmap = Bitmap.CreateScaledBitmap(mOriginalBitmap, iW, iH, true);
            return mOriginalBitmap;
        }
    }



    public class MenuCircle
    {
        public int x, y, radius;
        public int id;
        public string text;
        public Bitmap Imglink;

    }
}