using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Hardware.Fingerprints;
using Java.Lang;
using Java.Security;
using Javax.Crypto;
using Android.Security.Keystore;
using static Android.Hardware.Fingerprints.FingerprintManager;

namespace Cobalt.Android.Helper
{
   public class FingerprintHandler: FingerprintManager.AuthenticationCallback
    {

        TextView tv;


        public FingerprintHandler(TextView tv)
        {
            this.tv = tv;
        }

        public  void OnAuthenticationError(FingerprintState errorCode, ICharSequence errString) 
        {
            base.OnAuthenticationError(errorCode, errString);
        }
        
         public void onAuthenticationHelp(FingerprintState helpCode, ICharSequence helpString)
        {
            base.OnAuthenticationHelp(helpCode, helpString);

        }
      
        public void OnAuthenticationSucceeded(FingerprintManager.AuthenticationResult result)
        {
            base.OnAuthenticationSucceeded(result);
           
        }

   
        public void onAuthenticationFailed()
        {
            base.OnAuthenticationFailed();
        }

        public void doAuth(FingerprintManager manager, FingerprintManager.CryptoObject obj)
        {
            CancellationSignal signal = new CancellationSignal();

            try
            {
                manager.Authenticate(obj, signal, 0, this, null);
            }
            catch (SecurityException sce) { }
        }

    }

    /// <summary>
    /// Sample code for building a CryptoWrapper
    /// </summary>
    public class CryptoObjectHelper
    {
        // This can be key name you want. Should be unique for the app.
        static readonly string KEY_NAME = "com.jccbowers.cobalt.fingerprint_authentication_key";

        // We always use this keystore on Android.
        static readonly string KEYSTORE_NAME = "AndroidKeystore";

        // Should be no need to change these values.
        static readonly string KEY_ALGORITHM = KeyProperties.KeyAlgorithmAes;
        static readonly string BLOCK_MODE = KeyProperties.BlockModeCbc;
        static readonly string ENCRYPTION_PADDING = KeyProperties.EncryptionPaddingPkcs7;
        static readonly string TRANSFORMATION = KEY_ALGORITHM + "/" +
                                                BLOCK_MODE + "/" +
                                                ENCRYPTION_PADDING;
        readonly KeyStore _keystore;

        public CryptoObjectHelper()
        {
            _keystore = KeyStore.GetInstance(KEYSTORE_NAME);
            _keystore.Load(null);
        }

        public CryptoObject BuildCryptoObject()
        {
            Cipher cipher = CreateCipher();
            return new CryptoObject(cipher);
        }

        Cipher CreateCipher(bool retry = true)
        {
            IKey key = GetKey();
            Cipher cipher = Cipher.GetInstance(TRANSFORMATION);
            try
            {
                cipher.Init(CipherMode.EncryptMode | CipherMode.DecryptMode, key);
            }
            catch (KeyPermanentlyInvalidatedException e)
            {
                _keystore.DeleteEntry(KEY_NAME);
                if (retry)
                {
                    CreateCipher(false);
                }
                else
                {
                    throw new Java.Lang.Exception("Could not create the cipher for fingerprint authentication.", e);
                }
            }
            return cipher;
        }

        IKey GetKey()
        {
            IKey secretKey;
            if (!_keystore.IsKeyEntry(KEY_NAME))
            {
                CreateKey();
            }

            secretKey = _keystore.GetKey(KEY_NAME, null);
            return secretKey;
        }

        void CreateKey()
        {
            KeyGenerator keyGen = KeyGenerator.GetInstance(KeyProperties.KeyAlgorithmAes, KEYSTORE_NAME);
            KeyGenParameterSpec keyGenSpec =
                new KeyGenParameterSpec.Builder(KEY_NAME, KeyStorePurpose.Encrypt | KeyStorePurpose.Decrypt)
                    .SetBlockModes(BLOCK_MODE)
                    .SetEncryptionPaddings(ENCRYPTION_PADDING)
                    .SetUserAuthenticationRequired(true)
                    .Build();
            keyGen.Init(keyGenSpec);
            keyGen.GenerateKey();
        }
    }
}