﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cobalt.Droid.Utils
{
    public class NetworkResponse
    {
        public bool ResponseStatus { get; set; }
        public string ResponseErrorContent { get; set; }
        public object ResponseResult { get; set; }
    }
}
