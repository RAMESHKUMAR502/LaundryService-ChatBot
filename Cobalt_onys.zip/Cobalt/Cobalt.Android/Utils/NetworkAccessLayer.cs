﻿
using Cobalt.AsyncTask;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;


namespace Cobalt.Droid.Utils
{
    public class NetworkAccessLayer
    {
#if NOT
        public async Task<NetworkResponse> MakeGetRequest(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();
            
            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleSearch));
                        VehicleSearch searchedVehicle = (VehicleSearch)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicle;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch(WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }

        public async Task<NetworkResponse> GetVehicleYear(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();

            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleYear));
                        VehicleYear searchedVehicle = (VehicleYear)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicle;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch (WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }


        public async Task<NetworkResponse> GetVehicleMakeByYear(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();

            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleMake));
                        VehicleMake searchedVehicleMakes = (VehicleMake)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicleMakes;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch (WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }

        public async Task<NetworkResponse> GetVehicleModelbyMakeAndYear(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();

            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleModels));
                        VehicleModels searchedVehicleModels = (VehicleModels)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicleModels;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch (WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }

        public async Task<NetworkResponse> GetVehicleVersionbyMakeAndModel(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();

            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleVersions));
                        VehicleVersions searchedVehicleVersions = (VehicleVersions)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicleVersions;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch (WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }

       public async Task<NetworkResponse> GetVehicleTransmissionsByMid(string requestURL)
        {
            NetworkResponse result = new NetworkResponse();

            try
            {
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(requestURL);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = false;
                    try
                    {
                        DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(VehicleTransmissions));
                        VehicleTransmissions searchedVehicleTransmissions = (VehicleTransmissions)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                        result.ResponseResult = searchedVehicleTransmissions;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    result.ResponseStatus = true;
                    StreamReader reader = new StreamReader(await response.Content.ReadAsStreamAsync());
                    result.ResponseErrorContent = await reader.ReadToEndAsync();
                }
            }
            catch (WebException webExp)
            {
                result.ResponseStatus = true;
            }
            catch (Exception exp)
            {
                result.ResponseStatus = true;
            }
            return result;
        }
#endif

        public async Task<NetworkResponse> MakePostRequest(string requestURL, string bodyContent)
        {
            NetworkResponse result = new NetworkResponse();
            HttpClient client = new HttpClient();
            HttpContent requestContent = new StringContent(bodyContent, Encoding.UTF8, "application/json");
            try
            {
                HttpResponseMessage response = await client.PostAsync(requestURL, requestContent);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    result.ResponseStatus = true;
                    DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(LoggedInUser));
                    LoggedInUser currentUser = (LoggedInUser)jsonSerializer.ReadObject(await response.Content.ReadAsStreamAsync());
                    result.ResponseResult = currentUser;
                }
                else
                {
                    result.ResponseStatus = false;
                    result.ResponseErrorContent = await response.Content.ReadAsStringAsync();
                }
            }
            catch(Exception exp)
            {
                result.ResponseStatus = false;
            }
            return result;
        }
    }
}