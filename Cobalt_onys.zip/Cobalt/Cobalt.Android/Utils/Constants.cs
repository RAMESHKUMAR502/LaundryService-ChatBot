using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Cobalt.Android.Utils
{
    public enum ActivityType
    {
        FORGOTPWAD,
        NEWCEVICEREG


    }
   class Constants
    {
        public const string HOST_NAME = "http://cobalt-fe-api-dev.azurewebsites.net";
        //  public const string API_HOST = "https://" + HOST_NAME + "/iv";

        //public const string CobiregUi = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?s=OKa-AA9fWNc.cwA.3L0.x3nOS2l7a7MvbNirrG8H18e3m8dIbPzBjW4QHI-vhTY&screen=register";

        public const string CobiregUi = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?screen=register";
		public const string LoginregUi = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?screen=login";
		
        public const string loginURL = HOST_NAME + "/api/v1/user/login";
       public const string registerUserURL = HOST_NAME + "/api/v1/user/signup";
       public const string CHATBOTWEBVIEW = "https://cobaltdev.blob.core.windows.net/static-chatbot/botchat.html?s=abaXMIPkgbM.cwA.V98.k4iG8akLXPY_jFF2tSUQJ4dI8_bVGtdJUewXsGggXjsusertoken=";

        public const int LOGIN_ATTEMPT = 3;

    }
}