using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;
using Android.Util;
using System.Threading.Tasks;
using Cobalt.Android.Utils;
using Cobalt.Models;
using Cobalt.Common;
using Android.Content.PM;
using Cobalt.Android.Fragments;
using Android.Text.Util;
using Android.Text;
using Android.Text.Style;
using Java.Util;
using Android.Support.Design.Widget;
using Android.Hardware.Fingerprints;
using Android.Support.V4.Hardware.Fingerprint;
using Android.Graphics;
using Plugin.Fingerprint;
using System.Threading;
using Plugin.CurrentActivity;
using Plugin.Fingerprint.Abstractions;


namespace Cobalt.Android.Activites
{

    [Activity(Label = "LoginActivity", ScreenOrientation = ScreenOrientation.Portrait)]
    public class LoginActivity : AppComCustomeActivty
    {
        private static int TIME_DELAY = 2000;
        private static long back_pressed;
        EditText _emailText;
        EditText _passwordText;
        Button _loginButton;
        TextView _signupLink;
        TextView _ForgotPassLink;
        TextInputLayout tilpwd;
         TextView _fingerTxt;
        FingerprintManagerCompat _fingerprintManager;
        TextView _ImgView;

        protected override async void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.Loginlayout);

            _ImgView = FindViewById<TextView>(Resource.Id.help_icon);

            _ImgView.Click += _ImgView_Click;

            _emailText = FindViewById<EditText>(Resource.Id.input_email);
            _passwordText = FindViewById<EditText>(Resource.Id.input_password);
            _loginButton = FindViewById<Button>(Resource.Id.btn_login);
            _signupLink = FindViewById<TextView>(Resource.Id.link_signup);
            _ForgotPassLink = FindViewById< TextView > (Resource.Id.link_ForGotpassup);

            _fingerTxt = FindViewById<TextView>(Resource.Id.fingerprint_description);
          

            if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("username")))
             {

                _emailText.Text = AppSharedPreferencesSingleton.GetInstance().getAccessKey("username");
             }
            tilpwd = tilpwd = FindViewById<TextInputLayout>(Resource.Id.Txtinput_Password);
            _passwordText.FocusChange += _passwordText_FocusChange;
            _emailText.AfterTextChanged += _emailText_AfterTextChanged;
            _passwordText.AfterTextChanged += _emailText_AfterTextChanged;
            _loginButton.Click += _loginButton_Click;
            _loginButton.Alpha = 0.5f;
            _loginButton.Enabled = false;
          
            _ForgotPassLink.Click += _ForgotPassLink_Click;
            _signupLink.Click += _signupLink_Click;
            _fingerprintManager = FingerprintManagerCompat.From(this);

            if (await CheckFinger())
                _fingerTxt.Visibility = ViewStates.Visible;
            else
                _fingerTxt.Visibility = ViewStates.Gone;

            CrossFingerprint.SetCurrentActivityResolver(() => CrossCurrentActivity.Current.Activity);

            CrossFingerprint.SetDialogFragmentType<MyCustomDialogFragment>();

            _fingerTxt.Click += _fingerTouch_Click;
        }

        private void _fingerTouch_Click(object sender, EventArgs e)
        {
            try
            {
                //if (IsloginAttepentLock())
                //    return;

                ShowThumbprintDialog();
            }
            catch(Exception ex)
            {

            }
        }

        private void _passwordText_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                tilpwd.Error = GetString(Resource.String.PwdCmplxError);
                tilpwd.ErrorEnabled = true;
            }
            else
                tilpwd.ErrorEnabled = false;
        }

        private void _emailText_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(_emailText.Text.ToString()) 
                    || string.IsNullOrEmpty(_passwordText.Text.ToString()))
                {
                    _loginButton.Alpha = 0.5f;
                    _loginButton.Enabled = false;
                }
                else
                {
                    _loginButton.Alpha = 1.0f;
                    _loginButton.Enabled = true;
                }
            }
            catch(Exception ex)
            {

            }
        }

        private void _ForgotPassLink_Click(object sender, EventArgs e)
        {
            ShowEmailDiaFragmentDia();         
        }

        private void _signupLink_Click(object sender, EventArgs e)
        {
            onClickNewSignUp();
        }

        private void _loginButton_Click(object sender, EventArgs e)
        {
            //if (IsloginAttepentLock())
            //    return;

            login();
        }

        public void onClickNewSignUp()
        {
            StartActivity(new Intent(Application.Context, typeof(SignupActivity)));
            Finish();
               
        }


        public async void login()
        {
            ProgressDialog dialog = ProgressDialog.Show(this, GetString(Resource.String.Lgin), GetString(Resource.String.PlzWait), true, false);

            try
            {

                if (!validate())
                {
                    dialog.Hide();
                    onLoginFailed(null);
                    return;
                }
               
                _loginButton.Enabled = false;

                 dialog.Show();

                User _usr = new User();
                _usr.email = _emailText.Text.ToString();
                _usr.password = _passwordText.Text.ToString();

                Error _error = ControlValidation.Login(_usr);
                if (_error.hasError)
                {
                    dialog.Hide();
                    string ErrorMessage = _error.errorMessage;
                    Toast.MakeText(this, ErrorMessage, ToastLength.Short).Show();
                    return;
                }

                User _User = await Core.AuthenticateUser(_usr);

                if (_User != null) //Successfully Logged in
                {
                    if (_User.status == 200) //logged in successfully
                    {

                        string token = _User.userToken;
                        string userId = _User.userid;
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("username", _emailText.Text.ToString());
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Password", _passwordText.Text.ToString());
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("islogin", "true");
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("token", token);
                        LoginAttempts.GetInstance().RemoveLoginAttempts();

                        string EncpUserid = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.userid);
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("userid", EncpUserid);


                        string DecrpdeviceID = null;
                        if(!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId")))
                        {
                            DecrpdeviceID = AppSharedPreferencesSingleton.GetInstance().decrypt(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId"));
                            
                        }
                        bool isValidDevice = false;

                        if (DecrpdeviceID != null && _User.uniqueDeviceId != null)
                                isValidDevice = Core.ValidateDevice(DecrpdeviceID, _User.uniqueDeviceId);
                     

                        if (_User.uniqueDeviceId != null)
                        {
                            string EncpdeviceID = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.uniqueDeviceId);
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("UnquieDeviceId", EncpdeviceID);
                        }
                        if (_User.mobileNumber != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Mobile", _User.mobileNumber);
                        if (_User.isActive != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("isActive", _User.isActive);

                   if(isValidDevice == true)
                        StartActivity(new Intent(Application.Context, typeof(HomePage)));
                   else
                     StartActivity(new Intent(Application.Context, typeof(StartprovisionActivity)));
                        dialog.Hide();
                        Finish();
                    }
                    else
                    {
                        dialog.Hide();
                       // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                       if(_User.message != null)
                         onLoginFailed(_User.message);
                       else
                            onLoginFailed(null);
                  
                    }
                }
                else
                {
                    dialog.Hide();
                   // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                    onLoginFailed(null);
                }

                dialog.Hide();               
               
            }
            catch(Exception ex)
            {
                dialog.Hide();
                onLoginFailed(null);
                

            }
        }

        public async void loginThumbPrint()
        {
            
            if(string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("username"))
                || string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("Password")))

                {
                Toast toast = Toast.MakeText(this, GetString(Resource.String.ActThumReg),
                   ToastLength.Long);

                toast.View.SetBackgroundColor(Color.Red);
                toast.SetGravity(GravityFlags.CenterVertical, 0, 0);
                toast.Show();
               
                    return;

                 }
            ProgressDialog dialog = ProgressDialog.Show(this, GetString(Resource.String.Lgin), GetString(Resource.String.PlzWait), true, false);

            try
            {

            

                dialog.Show();

                User _usr = new User();

            
                _usr.email = AppSharedPreferencesSingleton.GetInstance().getAccessKey("username"); ;
                _usr.password = AppSharedPreferencesSingleton.GetInstance().getAccessKey("Password"); ;

                Error _error = ControlValidation.Login(_usr);
                if (_error.hasError)
                {
                    dialog.Hide();
                    string ErrorMessage = _error.errorMessage;
                    Toast.MakeText(this, ErrorMessage, ToastLength.Short).Show();
                    return;
                }

                User _User = await Core.AuthenticateUser(_usr);

                if (_User != null) //Successfully Logged in
                {
                    if (_User.status == 200) //logged in successfully
                    {

                        string token = _User.userToken;
                        string userId = _User.userid;
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("username", _emailText.Text.ToString());
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Password", _passwordText.Text.ToString());
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("islogin", "true");
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("token", token);
                        LoginAttempts.GetInstance().RemoveLoginAttempts();

                        string EncpUserid = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.userid);
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("userid", EncpUserid);


                        string DecrpdeviceID = null;
                        if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId")))
                        {
                            DecrpdeviceID = AppSharedPreferencesSingleton.GetInstance().decrypt(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId"));

                        }
                        bool isValidDevice = false;

                        if (DecrpdeviceID != null && _User.uniqueDeviceId != null)
                            isValidDevice = Core.ValidateDevice(DecrpdeviceID, _User.uniqueDeviceId);


                        if (_User.uniqueDeviceId != null)
                        {
                            string EncpdeviceID = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.uniqueDeviceId);
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("UnquieDeviceId", EncpdeviceID);
                        }
                        if (_User.mobileNumber != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Mobile", _User.mobileNumber);
                        if (_User.isActive != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("isActive", _User.isActive);

                        if (isValidDevice == true)
                            StartActivity(new Intent(Application.Context, typeof(HomePage)));
                        else
                            StartActivity(new Intent(Application.Context, typeof(StartprovisionActivity)));
                        dialog.Hide();
                        Finish();
                    }
                    else
                    {
                        dialog.Hide();
                        // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                        if (_User.message != null)
                            onLoginFailed(_User.message);
                        else
                            onLoginFailed(null);

                    }
                }
                else
                {
                    dialog.Hide();
                    // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                    onLoginFailed(null);
                }

                dialog.Hide();

            }
            catch (Exception ex)
            {
                dialog.Hide();
                onLoginFailed(null);


            }
        }



        public void onLoginSuccess()
        {
            _loginButton.Enabled = true;
           
        }

        public void onLoginFailed(string aTextMessage)
        {
            string mesg = GetString(Resource.String.LginFailed);


            if (aTextMessage != null)
            {
                if(aTextMessage.Contains(GetString(Resource.String.ActLocked)))
                {
                    mesg = GetString(Resource.String.LoginAttemptFalied); 
                }
                else if(aTextMessage.Contains("internal error"))
                {
                    mesg = GetString(Resource.String.ActReg);
                }
                else
                mesg = aTextMessage;
            }

            Toast toast = Toast.MakeText(this, mesg,
                     ToastLength.Long);
            
            toast.View.SetBackgroundColor(Color.Red);
            toast.SetGravity(GravityFlags.CenterVertical, 0, 0);
            toast.Show();
            _passwordText.Text = "";
            _loginButton.Enabled = true;

        }

    
        private async Task<bool> CheckFinger()
        {

            bool isv = await CrossFingerprint.Current.IsAvailableAsync();
            return isv;
#if NOT

            // Keyguard Manager
            KeyguardManager keyguardManager = (KeyguardManager)GetSystemService(KeyguardService);

            try
            {
                if (_fingerprintManager == null)
                {
                   // message.Text = "Fingerprint authentication not supported";
                    return false;
                }
                // Check if the fingerprint sensor is present
                if (!_fingerprintManager.IsHardwareDetected)
                {
                    //message.Text = "Fingerprint authentication not supported";
                   return false;
                }

                if (!_fingerprintManager.HasEnrolledFingerprints)
                {
                    //message.Text = "No fingerprint configured.";
                    return false;
                }

                if (!keyguardManager.IsKeyguardSecure)
                {
                   // message.Text = "Secure lock screen not enabled";
                    return false;
                }

            }
            catch (Java.Lang.SecurityException se)
            {
                se.PrintStackTrace();
            }


            return true;
#endif

        }
        public bool IsloginAttepentLock()
        {
            try
            {
                if(!_emailText.Text.Equals(AppSharedPreferencesSingleton.GetInstance().getAccessKey("username")))
                {
                    LoginAttempts.GetInstance().RemoveLoginAttempts();
                }
               bool isloginFailed =  LoginAttempts.GetInstance().isAccountLocked();

                if(isloginFailed ==  true)
                {
                    Toast toast = Toast.MakeText(this, GetString(Resource.String.LoginAttemptFalied),
                      ToastLength.Long);
                    toast.View.SetBackgroundColor(Color.Red);
                    toast.SetGravity(GravityFlags.CenterVertical, 0, 0);
                    toast.Show();
                }
                _loginButton.Enabled = true;

                return isloginFailed;

            }
            catch(Exception ex)
            {

            }
            return false;
        }

    public async void TestATHU()
        {
            var dialogConfig = new AuthenticationRequestConfiguration("Please Click on Scan !")
            {
                CancelTitle = "Cancel",
                FallbackTitle = "Scan!"
            };

            var result = await Plugin.Fingerprint.CrossFingerprint.Current.AuthenticateAsync(dialogConfig); //, _cancel.Token);

            if (result.Authenticated)
            {
                loginThumbPrint();
 
            }
            else
            {
                loginThumbPrint();
            }

        }
        public async void ShowThumbprintDialog()
        {
            try
            {
                TestATHU();
				

                //FragmentTransaction fragmentTransaction = FragmentManager.BeginTransaction();
                ////remove fragment from backstack if any exists
                //Fragment fragmentPrev = FragmentManager.FindFragmentByTag("dialog");
                //if (fragmentPrev != null)
                //    fragmentTransaction.Remove(fragmentPrev);

                //fragmentTransaction.AddToBackStack(null);
                ////create and show the dialog
                //ThumbPrintFragment dialogFragment = ThumbPrintFragment.NewInstace(_fingerprintManager);
                //dialogFragment.Show(fragmentTransaction, "ThumbPrint");
				
            }
            catch(Exception ex)
            {

            }
        }


        public void ThumbLoginScuess()
        {
            try
            {
                loginThumbPrint();
               // StartActivity(new Intent(Application.Context, typeof(HomePage)));               
                //Finish();
            }
          catch(Exception ex)
            {

            }
          
        }

        public void ThumbLoginFaild()
        {
            try
            {

                bool isloginFailed = LoginAttempts.GetInstance().isAccountLocked();

                if (isloginFailed == true)
                {
                    Toast toast = Toast.MakeText(this, GetString(Resource.String.LoginAttemptFalied),
                      ToastLength.Long);
                    toast.View.SetBackgroundColor(Color.Red);
                    toast.SetGravity(GravityFlags.CenterVertical, 0, 0);
                    toast.Show();
                }
                else
                {
                    Toast.MakeText(this, GetString(Resource.String.LginFailed),
                           ToastLength.Short).Show();
                }

            }
            catch (Exception ex)
            {

            }

        }


        public void ThumbScanFaild()
        {
            try
            {
                Toast.MakeText(this, GetString(Resource.String.fingerprint_not_recognized),
                       ToastLength.Short).Show();

            }
            catch (Exception ex)
            {

            }

        }

       
        public void ShowEmailDiaFragmentDia()
        {

            try
            {
                StartActivity(new Intent(Application.Context, typeof(ForgotPwdFlowActivity)));
            }
            catch (Exception ex)
            {

            }

        }

            

        public bool validate()
        {
            bool valid = true;

            string email = _emailText.Text.ToString();
            string password = _passwordText.Text.ToString();

            if (string.IsNullOrEmpty(email) || !Patterns.EmailAddress.Matcher(email).Matches())
            {
                _emailText.Error = GetString(Resource.String.EmailErr);
                valid = false;
            }
            else
            {
                _emailText.Error =null;
            }

            if (string.IsNullOrEmpty(password) || password.Length < 4 || password.Length > 10)
            {
                _passwordText.Error = GetString(Resource.String.PwdErrChar);
                valid = false;
            }
            else
            {
                _passwordText.Error = null;
            }

            return valid;
        }
#region LOGIFLOW
        public void ShowUnRegisterDialog()
        {
            try
            {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(Application.Context);
                alertDialog.SetTitle(Resource.String.UnReg);
                alertDialog.SetMessage(Resource.String.UnRegMeg);
                alertDialog.SetPositiveButton(Resource.String.BtnOk, (senderAlert, args) =>
                {
                   // ShowMobileFragmentDia();
                });
                alertDialog.SetNegativeButton(Resource.String.BtnCancel, (senderAlert, args) =>
                {
                    //Go To DASHBORAD
                  StartActivity(new Intent(Application.Context, typeof(HomePage)));

                    alertDialog.Dispose();
                });
                alertDialog.Show();
            }
            catch (Exception ex)
            {

            }
        }



#endregion


#region FINGERPRINT

#if NOT
        private bool CheckFinger()
        {

            // Keyguard Manager
            KeyguardManager keyguardManager = (KeyguardManager)GetSystemService(KeyguardService);

            // Fingerprint Manager
            FingerprintManager fingerprintManager = (FingerprintManager)GetSystemService(FingerprintService);

            try
            {
                // Check if the fingerprint sensor is present
                if (!fingerprintManager.IsHardwareDetected)
                {
                    _fingerTxt.Text = "Fingerprint authentication not supported";
                    return false;
                }

                if (!fingerprintManager.HasEnrolledFingerprints)
                {
                    _fingerTxt.Text = "No fingerprint configured.";
                    return false;
                }

                if (!keyguardManager.IsKeyguardSecure)
                {
                    _fingerTxt.Text = "Secure lock screen not enabled";
                    return false;
                }

            }
            catch (Java.Lang.SecurityException se)
            {
                se.PrintStackTrace();
            }


            return true;

        }

        public void HandleFingerPrint()
        {
            if (!CheckFinger())
            {

            }
            else
            {
                // We are ready to set up the cipher and the key
                try
                {
                    CryptoObjectHelper CryptoObjectHelper = new CryptoObjectHelper();

                    fph.doAuth(fingerprintManager, CryptoObjectHelper.BuildCryptoObject());

                }
                catch (Java.Lang.Exception fpe)
                {
                    // Handle exception

                }
            }

        }
#endif
#endregion
        private static readonly DateTime Jan1st1970 = new DateTime
   (1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);


        private void _ImgView_Click(object sender, EventArgs e)
        {
            try
            {
                var intent = new Intent(Application.Context, typeof(CobieWbviewActivity));
                intent.PutExtra("weburi", Constants.LoginregUi);

                StartActivity(intent);
               


               // StartActivity(new Intent(Intent.ActionView, global::Android.Net.Uri.Parse(Constants.LoginregUi)));
            }
            catch (Exception ex)
            {

            }
        }


        public long CurrentTimeMillis()
        {
            return (long)(DateTime.UtcNow - Jan1st1970).TotalMilliseconds;
        }

        public override void OnBackPressed()
        {
            if (back_pressed + TIME_DELAY > CurrentTimeMillis())
            {
                FinishAffinity();
            }
            else
            {
                Toast.MakeText(this, GetString(Resource.String.ExitPop),
                         ToastLength.Short).Show();
            }
            back_pressed = CurrentTimeMillis();
        }

        public void OnActivityCreated(Activity activity, Bundle savedInstanceState)
        {
            CrossCurrentActivity.Current.Activity = activity;
        }
        public void OnActivityStarted(Activity activity)
        {
            CrossCurrentActivity.Current.Activity = activity;
        }

        public void OnActivityResumed(Activity activity)
        {
            CrossCurrentActivity.Current.Activity = activity;
        }
    }
}