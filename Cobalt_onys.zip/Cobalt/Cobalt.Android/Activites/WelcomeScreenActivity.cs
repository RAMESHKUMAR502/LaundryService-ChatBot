using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;
using Android.Graphics;
using System.Timers;
using Felipecsl.GifImageViewLibrary;
using Android.Content.Res;
using System.IO;
using Android.Content.PM;

namespace Cobalt.Android.Activites
{

    [Activity(Label = "WelcomeScreenActivity", ScreenOrientation = ScreenOrientation.Portrait)]
    public class WelcomeScreenActivity : AppComCustomeActivty
    {       
        Timer timer = new System.Timers.Timer();
        TimeSpan time = TimeSpan.FromSeconds(60);
        InitCircularProgressClass initCircularProgressBar;
        GifImageView gifImageView;
        TextView ConteCra;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            RequestWindowFeature(WindowFeatures.NoTitle);
            SetContentView(Resource.Layout.WelcomeScreen);
            gifImageView = FindViewById<GifImageView>(Resource.Id.gifImageView);
            ConteCra = FindViewById<TextView>(Resource.Id.textView2);

            // Create your application here
            ShowGifAnmimation();
            fnInitializeCircleBar();
            fnStartTimer();
        }


        public byte[] ReadFully(Stream input)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                input.CopyTo(ms);
                return ms.ToArray();
            }
        }

        public void ShowGifAnmimation()
        {

            try
            {
              
              
                {
                    try
                    {
                        byte[] buffer = null;
                        AssetManager assets = this.Assets;
                        Stream input = assets.Open("cobaltrotating.gif");
                        buffer = ReadFully(input);
                        if (buffer != null)
                        {
                            gifImageView.SetBytes(buffer);
                            gifImageView.StartAnimation();
                        }
                        input.Close();

                    }
                    catch (Exception ex)
                    {

                    }
                  
                }


            }
            catch (Exception ex)
            {
                ActionBar.Title = "error downloading";
                Toast.MakeText(this, ex.ToString(), ToastLength.Long).Show();
            }

        }


        void fnInitializeCircleBar()
        {
            initCircularProgressBar = (InitCircularProgressClass)FindViewById(Resource.Id.rate_progress_bar);
            initCircularProgressBar.setMax(100);
            initCircularProgressBar.ClearAnimation();
            initCircularProgressBar.setTextSize(22);
            initCircularProgressBar.setTextColor(Color.DarkGray);
            initCircularProgressBar.setTextTypeFaceBold();
            initCircularProgressBar.setProgress(0);

            initCircularProgressBar.getCircularProgressBar().setCircleWidth(10);
            initCircularProgressBar.getCircularProgressBar().setMax(60);
            initCircularProgressBar.getCircularProgressBar().setPrimaryColor(Color.ParseColor("#0D85EC")); ;
            initCircularProgressBar.getCircularProgressBar().setBackgroundColor(Color.ParseColor("#83C6FF"));
        }
        void fnStartTimer()
        {
         
            timer.Interval = TimeSpan.FromSeconds(1).TotalMilliseconds/10;
            timer.Elapsed += OnTimedEvent;
            timer.Enabled = true;
           
        }
        void OnTimedEvent(object sender, System.Timers.ElapsedEventArgs e)
        {
            RunOnUiThread(FnUpdateProgress);
        }

        private void ShowText()
        {
            try
            {
                if(secondUpdate == 0)
                {
                    ConteCra.Text = "Connecting to Mobile...";
                }
                else if(secondUpdate == 15)
                {
                    ConteCra.Text = "Connecting to Appliances...";
                }
                else if (secondUpdate == 30)
                {
                    ConteCra.Text = "Connecting to House..."; ;

                }
                else if (secondUpdate == 45)
                {
                    ConteCra.Text = "Connecting to Car...";
                }
                else if (secondUpdate == 60)
                {
                    ConteCra.Text = "Connected";
                }

            }
            catch(Exception ex)
            {

            }
        }

        int secondUpdate = 0;
        public void FnUpdateProgress()
        {

            secondUpdate++;
            ShowText();
            if (secondUpdate <= 60)
            {
                initCircularProgressBar.setProgress(secondUpdate);
            }
            time -= TimeSpan.FromSeconds(1);
            if (time <= TimeSpan.Zero)
            {
                timer.Stop();
                initCircularProgressBar.ClearAnimation();
                initCircularProgressBar = null;
                initCircularProgressBar = (InitCircularProgressClass)FindViewById(Resource.Id.rate_progress_bar);
                secondUpdate = 0;
                initCircularProgressBar.setProgress(secondUpdate);
                if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("token")) 
                    || !string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("userid")))
                {
                    StartActivity(new Intent(Application.Context, typeof(HomePage)));
                }
                else
                {
                    StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                }
                Finish();
            }
           
            
        }

        protected override void OnStop()
        {
            base.OnStop();
            gifImageView.StopAnimation();
        }

        public override void OnBackPressed()
        {
            base.OnBackPressed();
            Finish();
        }
    }
}