using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Helper;
using HockeyApp.Android;
using Android.Net;
using System.Threading.Tasks;
using Java.Lang;
using Android.Content.PM;

namespace Cobalt.Android.Activites
{
    [Activity(NoHistory = true, MainLauncher = true, Label = "Cobalt", ScreenOrientation = ScreenOrientation.Portrait, ConfigurationChanges = ConfigChanges.Orientation)]
    public class SplashActivity : AppComCustomeActivty
    {
        private static int SplashTimeOut = 2000;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.SplaShScreenLayout);
            // Create your application here
            if (Build.VERSION.SdkInt >= BuildVersionCodes.Lollipop)
            {
                Window.AddFlags(WindowManagerFlags.DrawsSystemBarBackgrounds);
               // Window.SetStatusBarColor(new Android.Graphics.Color(ContextCompat.GetColor(this, Resource.Color.primaryDark)));
            }
        }

        protected override async void OnResume()
        {
            base.OnResume();
            await Task.Delay(SplashTimeOut);

            if (IsConnecting())
                {
                Nav();


                 }
            else
                {
                  AlertDialog.Builder alert = new AlertDialog.Builder(this);
                    alert.SetTitle("No Internet connection");
                    alert.SetMessage("Check your Internet connection");
                    Dialog dialog = alert.Create();
                    dialog.Show();                  
                    alert.Dispose();
                //StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                Nav();
            }
        }

        public void Nav()
        {

            if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("token"))
                   || !string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("userid")))
            {
                StartActivity(new Intent(Application.Context, typeof(HomePage)));
            }
            else
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
            }
            Finish();
        }


        public bool IsConnecting()
        {
            ConnectivityManager connectivity = (ConnectivityManager)this
              .GetSystemService(Context.ConnectivityService);

            if (connectivity != null)
            {
                NetworkInfo info = connectivity.ActiveNetworkInfo;
                if (info != null && info.GetState() == NetworkInfo.State.Connected)
                {
                    return true;
                }
            }
            return false;
        }


        private class crManagerListner : CrashManagerListener
        {
            public override bool ShouldAutoUploadCrashes()
            {
                return true;
            }
        }
    }
}