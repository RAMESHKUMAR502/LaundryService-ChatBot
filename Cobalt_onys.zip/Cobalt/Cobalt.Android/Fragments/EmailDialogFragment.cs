﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Activites;
using Fragment = Android.Support.V4.App.Fragment;
using Android.Views.InputMethods;
using Cobalt.Android.Helper;
using Cobalt.Android.Utils;

namespace Cobalt.Android.Fragments
{
    public class EmailDialogFragment : Fragment
    {

        private EditText _Email;
        private Button _Conbtn;
        private TextView AlredayView;
        ActivityType ActivityEnuType;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            return inflater.Inflate(Resource.Layout.EmailDialoglayout, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            _Email = (EditText)view.FindViewById(Resource.Id.email);
            _Conbtn = (Button)view.FindViewById(Resource.Id.smsVerificationButton);
            AlredayView = (TextView)view.FindViewById(Resource.Id.tvLoginLink);
            _Conbtn.Click += MSmsButton_Click;
            _Email.AfterTextChanged += _Email_AfterTextChanged;
            _Conbtn.Enabled = false;
            _Conbtn.Alpha = 0.5f;
            AlredayView.Click += AlredayView_Click;
            if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("username")))
            {
                _Email.Text = AppSharedPreferencesSingleton.GetInstance().getAccessKey("username");
            }


        }

        private void _Email_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(_Email.Text.ToString()))
                {
                    _Conbtn.Alpha = 0.5f;
                    _Conbtn.Enabled = false;
                }
                else
                {
                    _Conbtn.Alpha = 1.0f;
                    _Conbtn.Enabled = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }

        public void ActivityType(ActivityType actvtyType)
        {
            ActivityEnuType = actvtyType;
        }
 
   
        private void AlredayView_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                this.Activity.Finish();
            }
            catch (Exception ex)
            {

            }

        }

        private void MSmsButton_Click(object sender, EventArgs e)
        {
            try {
                if (!validate())
                    return;

                if (ActivityEnuType == Utils.ActivityType.FORGOTPWAD)
                {
                    ForgotPwdFlowActivity activity = (ForgotPwdFlowActivity)this.Activity;
                    if (activity != null)
                    {
                        //if Provision done 
                        //if(true)
                        //{
                        //    activity.ChangeFrga("MobileNumber");
                        //}
                        //else
                        activity.ChangeFrga("Validate");
                    }
                }
                else {

                    NewDeviceLoginActivity activity = (NewDeviceLoginActivity)this.Activity;
                    if (activity != null)
                    {
                        //if Provision done 
                        //if(true)
                        //{
                        //    activity.ChangeFrga("MobileNumber");
                        //}
                        //else
                        activity.ChangeFrga("Validate");
                    }
                }
            }
            catch(Exception ex) { }
        }

        public bool validate()
        {
            bool valid = true;

            string email = _Email.Text.ToString();
           

            if (string.IsNullOrEmpty(email) || !Patterns.EmailAddress.Matcher(email).Matches())
            {
                _Email.Error = GetString(Resource.String.EmailErr);
                valid = false;
            }
            else
            {
                _Email.Error = null;
            }

         

            return valid;
        }
    }
}