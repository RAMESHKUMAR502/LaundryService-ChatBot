using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
//using Android.Support.V4.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Android.Support.V4.Hardware.Fingerprint;
using Javax.Crypto;
using Cobalt.Android.Activites;
using Android.Hardware.Fingerprints;
using Cobalt.Android.Helper;
using Android.OS;
using Cobalt.Android.Utils;
using Plugin.Fingerprint.Dialog;
using Android.Graphics.Drawables;
using Android.Graphics;

namespace Cobalt.Android.Fragments
{
    public class ThumbPrintFragment : DialogFragment
    {
        Button _cancelButton;
        ImageView _ImgView;
        CancellationSignal _cancellationSignal;
        FingerprintManagerCompat _fingerprintManager;

        bool ScanForFingerprintsInOnResume { get; set; } = true;

        bool UserCancelledScan { get; set; }

        CryptoObjectHelper CryptObjectHelper { get; set; }
        static readonly string TAG = "X:" + typeof(ThumbPrintFragment).Name;


        bool IsScanningForFingerprints
        {
            // ReSharper disable once ConvertPropertyToExpressionBody
            get { return _cancellationSignal != null; }
        }


        public static ThumbPrintFragment NewInstace(FingerprintManagerCompat fingerprintManager)
        {
            ThumbPrintFragment fragment = new ThumbPrintFragment
            {
                _fingerprintManager = fingerprintManager
             };
            return fragment;
        }
        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View v = inflater.Inflate(Resource.Layout.ThumbLoginFragMent, container, false);

            Dialog.Window.RequestFeature(WindowFeatures.NoTitle); //remove title area
            Dialog.SetCanceledOnTouchOutside(false); //dismiss window on touch outside
            _ImgView = v.FindViewById<ImageView>(Resource.Id.fingerprint_icon);
            _ImgView.Click += _ImgView_Click;
            _cancelButton = v.FindViewById<Button>(Resource.Id.btnClearLL);
            _cancelButton.Click += (sender, args) =>
            {
                Dismiss();
            };
            CryptObjectHelper = new CryptoObjectHelper();
            if(CryptObjectHelper != null)
            {
               
            }

            return v;
        }

        private void _ImgView_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ScanForFingerprintsInOnResume)
                {
                    return;
                }

                UserCancelledScan = false;
                _cancellationSignal = new CancellationSignal();
                _fingerprintManager.Authenticate(CryptObjectHelper.BuildCryptoObject(),
                                                 (int)FingerprintAuthenticationFlags.None, /* flags */
                                                 null,
                                                 new SimpleAuthCallbacks(this),
                                                 null);

            }
            catch(Java.Lang.Exception ex)
            {

            }
        }




        public override void OnResume()
        {
            base.OnResume();
          
        }

        public override void OnPause()
        {
            base.OnPause();
            if (IsScanningForFingerprints)
            {
                StopListeningForFingerprints(true);
            }
        }

        void StopListeningForFingerprints(bool butStartListeningAgainInOnResume = false)
        {
            if (_cancellationSignal != null)
            {
                _cancellationSignal.Cancel();
                _cancellationSignal = null;
                Log.Debug(TAG, "StopListeningForFingerprints: _cancellationSignal.Cancel();");
            }
            ScanForFingerprintsInOnResume = butStartListeningAgainInOnResume;
        }

        public override void OnDestroyView()
        {
            // see https://code.google.com/p/android/issues/detail?id=17423
            if (Dialog != null && RetainInstance)
            {
                Dialog.SetDismissMessage(null);
            }
            base.OnDestroyView();
        }

        class SimpleAuthCallbacks : FingerprintManagerCompat.AuthenticationCallback
        {
            // ReSharper disable once MemberHidesStaticFromOuterClass
            static readonly string TAG = "X:" + typeof(SimpleAuthCallbacks).Name;
            static readonly byte[] SECRET_BYTES = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            readonly ThumbPrintFragment _fragment;

            public SimpleAuthCallbacks(ThumbPrintFragment frag)
            {
                _fragment = frag;
            }

            public override void OnAuthenticationSucceeded(FingerprintManagerCompat.AuthenticationResult result)
            {
                Log.Debug(TAG, "OnAuthenticationSucceeded");
                if (result.CryptoObject.Cipher != null)
                {
                    try
                    {
                        // Calling DoFinal on the Cipher ensures that the encryption worked.
                        byte[] doFinalResult = result.CryptoObject.Cipher.DoFinal(SECRET_BYTES);
                        Log.Debug(TAG, "Fingerprint authentication succeeded, doFinal results: {0}",
                                  Convert.ToBase64String(doFinalResult));

                        ReportSuccess();
                    }
                    catch (BadPaddingException bpe)
                    {
                        Log.Error(TAG, "Failed to encrypt the data with the generated key." + bpe);
                        ReportAuthenticationFailed();
                    }
                    catch (IllegalBlockSizeException ibse)
                    {
                        Log.Error(TAG, "Failed to encrypt the data with the generated key." + ibse);
                        ReportAuthenticationFailed();
                    }
                }
                else
                {
                    // No cipher used, assume that everything went well and trust the results.
                    Log.Debug(TAG, "Fingerprint authentication succeeded.");
                    ReportSuccess();
                }
            }

     
            void ReportSuccess()
            {
                LoginActivity activity = (LoginActivity)_fragment.Activity;
                LoginAttempts.GetInstance().RemoveLoginAttempts();
                _fragment.Dismiss();
                if (activity != null)
                {
                    activity.loginThumbPrint();
                    //Add logic for to SAVE USERID and Move to...

                    activity.ThumbLoginScuess();
                }
            }

            void ReportScanFailure(int errMsgId, string errorMessage)
            {
                LoginActivity activity = (LoginActivity)_fragment.Activity;
                /// activity.ShowError(errorMessage, string.Format("Error message id {0}.", errMsgId));
                LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                _fragment.Dismiss();
                activity.ThumbScanFaild();
            }

            void ReportAuthenticationFailed()
            {
                LoginActivity activity = (LoginActivity)_fragment.Activity;
                LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                _fragment.Dismiss();
                activity.ThumbLoginFaild();
           
            }

            public override void OnAuthenticationError(int errMsgId, ICharSequence errString)
            {
                // There are some situations where we don't care about the error. For example, 
                // if the user cancelled the scan, this will raise errorID #5. We don't want to
                // report that, we'll just ignore it as that event is a part of the workflow.
                bool reportError = (errMsgId == (int)FingerprintState.ErrorCanceled) &&
                                   !_fragment.ScanForFingerprintsInOnResume;

                string debugMsg = string.Format("OnAuthenticationError: {0}:`{1}`.", errMsgId, errString);

                if (_fragment.UserCancelledScan)
                {
                    // string msg = _fragment.Resources.GetString("Canceled");
                    string msg = "Canceled";
                    ReportScanFailure(-1, msg);
                }
                else if (reportError)
                {
                    ReportScanFailure(errMsgId, errString.ToString());
                    debugMsg += " Reporting the error.";
                }
                else
                {
                    debugMsg += " Ignoring the error.";
                }
                Log.Debug(TAG, debugMsg);
            }

            public override void OnAuthenticationFailed()
            {
                Log.Info(TAG, "Authentication failed.");
                ReportAuthenticationFailed();
            }

            public override void OnAuthenticationHelp(int helpMsgId, ICharSequence helpString)
            {
                Log.Debug(TAG, "OnAuthenticationHelp: {0}:`{1}`", helpString, helpMsgId);
                ReportScanFailure(helpMsgId, helpString.ToString());
            }
        }
    }

    public class MyCustomDialogFragment : FingerprintDialogFragment
    {
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = base.OnCreateView(inflater, container, savedInstanceState);
            view.Background = new ColorDrawable(Color.ParseColor("#83C6FF"));
            return view;
        }
    }

}