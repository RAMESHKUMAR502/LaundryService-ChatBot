using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Cobalt.Android.Activites;
using Fragment = Android.Support.V4.App.Fragment;
using Cobalt.Android.Utils;

namespace Cobalt.Android.Fragments
{
    public class ValidateDialogFragment: Fragment
    {
        EditText EditTxet;
        Button Validatebtn;
        Button ResendTxtView;
        TextView TimerTextview;
        private System.Timers.Timer _timer;
        private int _countSeconds = 30;
        private TextView AlredayView;


        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            return inflater.Inflate(Resource.Layout.activity_verification, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            EditTxet = (EditText)view.FindViewById(Resource.Id.et_code1);
            Validatebtn = (Button)view.FindViewById(Resource.Id.btnLoginLL);
            ResendTxtView = (Button)view.FindViewById(Resource.Id.tv_resend_otp);
            AlredayView = (TextView)view.FindViewById(Resource.Id.tvLoginLink);
            TimerTextview = (TextView)view.FindViewById(Resource.Id.tv_Timer_otp);
            TimerTextview.Text = _countSeconds + " Sec";
            Validatebtn.Alpha = 0.5f;
            Validatebtn.Enabled = false;
            ResendTxtView.Alpha = 0.5f;
            ResendTxtView.Enabled = false;
            EditTxet.AfterTextChanged += _Email_AfterTextChanged;
            _timer = new System.Timers.Timer();
            //Trigger event every second
            _timer.Interval = 1000;
            _timer.Elapsed += OnTimedEvent;
            //count down 5 seconds


            
            Validatebtn.Click += Validatebtn_Click;

            ResendTxtView.Click += ResendTxtView_Click;
            AlredayView.Click += AlredayView_Click;




        }

        private void AlredayView_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                this.Activity.Finish();
            }
            catch (Exception ex)
            {

            }
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }


        private void _Email_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(EditTxet.Text.ToString()))
                {
                    Validatebtn.Alpha = 0.5f;
                    Validatebtn.Enabled = false;
                }
                else
                {
                    Validatebtn.Alpha = 1.0f;
                    Validatebtn.Enabled = true;
                }
            }
            catch (Exception ex)
            {

            }
        }


        private void OnTimedEvent(object sender, System.Timers.ElapsedEventArgs e)
        {
            _countSeconds--;

            //Update visual representation here
            //Remember to do it on UI thread

            Activity.RunOnUiThread(() => this.TimerTextview.Text = (this._countSeconds.ToString() + " Sec"));

            if (_countSeconds == 0)
            {
                _timer.Stop();
                Activity.RunOnUiThread(() => { ResendTxtView.Enabled = true; ResendTxtView.Alpha = 1.0f; });

            }
        }

        private void ResendTxtView_Click(object sender, EventArgs e)
        {
            try
            {
                ResendTxtView.Enabled = false;
                ResendTxtView.Alpha = 0.5f;
                _countSeconds = 30;
                this.TimerTextview.Text = _countSeconds.ToString() + " Sec";
                _timer.Start();
            }
            catch (Exception ex)
            {

            }
        }
        ActivityType ActivityEnuType;

        public void ActivityType(ActivityType actvtyType)
        {
            ActivityEnuType = actvtyType;
        }

        private void Validatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Validate())
                    return;
                //Register the Tablet And Go to DashBoard..
                _timer.Enabled = true;
                if (ActivityEnuType == Utils.ActivityType.FORGOTPWAD)
                {
                    ForgotPwdFlowActivity activity = (ForgotPwdFlowActivity)this.Activity;

                    if (activity != null)
                    {
                        activity.ChangeFrga("ChangePassword");
                    }
                }
                else
                {
                    NewDeviceLoginActivity activity = (NewDeviceLoginActivity)this.Activity;

                    if (activity != null)
                    {
                        //Show ProvisionalScreen/DashBoard--TODO
                       // activity.ChangeFrga("ChangePassword");
                    }

                }
            }
            catch (Exception ex)
            {

            }
        }
        public bool Validate()
        {

            bool valid = true;
            try
            {


                string email = EditTxet.Text.ToString();


                if (string.IsNullOrEmpty(email))
                {
                    EditTxet.Error = GetString(Resource.String.enterphonenumber);
                    valid = false;
                }
                else
                {
                    EditTxet.Error = null;
                }


            }
            catch (Exception ex)
            {

            }
            return valid;
        }
    }
}