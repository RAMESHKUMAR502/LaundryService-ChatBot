﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Fragment = Android.Support.V4.App.Fragment;
using Cobalt.Android.Activites;
using Android.Support.Design.Widget;
using Cobalt.Models;
using Cobalt.Common;
using Cobalt.Android.Helper;
using Cobalt.Android.Utils;
using Android.Graphics;

namespace Cobalt.Android.Fragments
{
    public class ChnagePasswordfrg : Fragment
    {
        private Button _Conbtn;
        private TextView AlredayView;
        private TextView _newpasw;
        private TextView _repasw;
        TextInputLayout til;
        TextInputLayout tilpwd;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            // Use this to return your custom view for this Fragment
            return inflater.Inflate(Resource.Layout.ChangePwdlayout, container, false);

            //return base.OnCreateView(inflater, container, savedInstanceState);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            _newpasw = (EditText)view.FindViewById(Resource.Id.input_password);
            _repasw = (EditText)view.FindViewById(Resource.Id.input_reEnterPassword);
            _Conbtn = (Button)view.FindViewById(Resource.Id.smsVerificationButton);
            AlredayView = (TextView)view.FindViewById(Resource.Id.tvLoginLink);
            tilpwd = view.FindViewById<TextInputLayout>(Resource.Id.Txtinput_reEnterPassword);
            til = view.FindViewById<TextInputLayout>(Resource.Id.Txtinput_Password);
            _repasw.FocusChange += _reEnterPasswordText_FocusChange;
            _newpasw.FocusChange += _passwordText_FocusChange;
            _Conbtn.Click += _Conbtn_Click; ;
            _newpasw.AfterTextChanged += _Email_AfterTextChanged;
            _repasw.AfterTextChanged += _Email_AfterTextChanged;
            _Conbtn.Enabled = false;
            _Conbtn.Alpha = 0.5f;
            AlredayView.Click += AlredayView_Click;



        }

        private void _passwordText_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                til.Error = GetString(Resource.String.PwdCmplxError);
                til.ErrorEnabled = true;
            }
            else
                til.ErrorEnabled = false;

        }

        private void _reEnterPasswordText_FocusChange(object sender, View.FocusChangeEventArgs e)
        {
            if (e.HasFocus)
            {
                tilpwd.Error = GetString(Resource.String.PwdCmplxError);
                tilpwd.ErrorEnabled = true;
            }
            else
                tilpwd.ErrorEnabled = false;
        }

        private void _newpasw_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            
        }

        private void _Conbtn_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {


            }
        }

        public async void ChnagePassssword()
        {
            ProgressDialog dialog = ProgressDialog.Show(this.Context, GetString(Resource.String.Lgin), GetString(Resource.String.PlzWait), true, false);

            try
            {

                if (!validate())
                {
                    dialog.Hide();
                    onLoginFailed(null);
                    return;
                }

                _Conbtn.Enabled = false;

                dialog.Show();

                User _usr = new User();
                _usr.email = _newpasw.Text.ToString();
                _usr.password = _repasw.Text.ToString();

                Error _error = ControlValidation.Login(_usr);
                if (_error.hasError)
                {
                    dialog.Hide();
                    string ErrorMessage = _error.errorMessage;
                    Toast.MakeText(this.Context, ErrorMessage, ToastLength.Short).Show();
                    return;
                }

                User _User = await Core.AuthenticateUser(_usr);

                if (_User != null) //Successfully Logged in
                {
                    if (_User.status == 200) //logged in successfully
                    {

                        string token = _User.userToken;
                        string userId = _User.userid;
                         AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Password",_newpasw.Text.ToString());
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("islogin", "true");
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("token", token);
                        LoginAttempts.GetInstance().RemoveLoginAttempts();

                        string EncpUserid = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.userid);
                        AppSharedPreferencesSingleton.GetInstance().saveAccessKey("userid", EncpUserid);


                        string DecrpdeviceID = null;
                        if (!string.IsNullOrEmpty(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId")))
                        {
                            DecrpdeviceID = AppSharedPreferencesSingleton.GetInstance().decrypt(AppSharedPreferencesSingleton.GetInstance().getAccessKey("UnquieDeviceId"));

                        }
                        bool isValidDevice = false;

                        if (DecrpdeviceID != null && _User.uniqueDeviceId != null)
                            isValidDevice = Core.ValidateDevice(DecrpdeviceID, _User.uniqueDeviceId);


                        if (_User.uniqueDeviceId != null)
                        {
                            string EncpdeviceID = AppSharedPreferencesSingleton.GetInstance().encrypt(_User.uniqueDeviceId);
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("UnquieDeviceId", EncpdeviceID);
                        }
                        if (_User.mobileNumber != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("Mobile", _User.mobileNumber);
                        if (_User.isActive != null)
                            AppSharedPreferencesSingleton.GetInstance().saveAccessKey("isActive", _User.isActive);

                        if (isValidDevice == true)
                            StartActivity(new Intent(Application.Context, typeof(HomePage)));
                        else
                            StartActivity(new Intent(Application.Context, typeof(StartprovisionActivity)));
                        dialog.Hide();
                        this.Activity.Finish();
                    }
                    else
                    {
                        dialog.Hide();
                        // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                        if (_User.message != null)
                            onLoginFailed(_User.message);
                        else
                            onLoginFailed(null);

                    }
                }
                else
                {
                    dialog.Hide();
                    // LoginAttempts.GetInstance().SaveLoginFaliedAttemps();
                    onLoginFailed(null);
                }

                dialog.Hide();

            }
            catch (Exception ex)
            {
                dialog.Hide();
                onLoginFailed(null);


            }
        }
        public void onLoginFailed(string aTextMessage)
        {
            string mesg = GetString(Resource.String.LginFailed);


            if (aTextMessage != null)
            {
                if (aTextMessage.Contains(GetString(Resource.String.ActLocked)))
                {
                    mesg = GetString(Resource.String.LoginAttemptFalied);
                }
                else if (aTextMessage.Contains("internal error"))
                {
                    mesg = GetString(Resource.String.ActReg);
                }
                else
                    mesg = aTextMessage;
            }

            Toast toast = Toast.MakeText(this.Context, mesg,
                     ToastLength.Long);

            toast.View.SetBackgroundColor(Color.Red);
            toast.SetGravity(GravityFlags.CenterVertical, 0, 0);
            toast.Show();
            _newpasw.Text = "";
            _Conbtn.Enabled = true;

        }


        public bool validate()
        {
            bool valid = true;

          
            string password = _newpasw.Text.ToString();
            string reEnterPassword = _repasw.Text.ToString();

            if (!IsvalidPassword(password))
            {
                _newpasw.Error = GetString(Resource.String.PwdCmplxError);
                valid = false;
            }
            else
            {
                _newpasw.Error = null;
            }

            if (!IsvalidPassword(reEnterPassword))
            {
                _repasw.Error = GetString(Resource.String.PwdCmplxError);
                valid = false;
            }
            else
            {
                _repasw.Error = null;
            }

            //  //    if (string.IsNullOrEmpty(reEnterPassword) || !IsvalidPassword(reEnterPassword) || !(reEnterPassword.Equals(password)))
            if (!string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(reEnterPassword))
            {
                if (password != reEnterPassword)
                {
                    _repasw.Error = GetString(Resource.String.PwdErrNotMatch);
                    valid = false;
                }
            }
            else
            {
                _repasw.Error = null;
            }

            return valid;
        }

        public bool IsvalidPassword(string apasswrd)
        {
            if (string.IsNullOrEmpty(apasswrd)) return false;
            if (System.Text.RegularExpressions.Regex.Match(apasswrd, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}").Success) return true;
            return false;
        }

        private void _Email_AfterTextChanged(object sender, global::Android.Text.AfterTextChangedEventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(_newpasw.Text.ToString())
                    || string.IsNullOrEmpty(_repasw.Text.ToString()))
                {
                    _Conbtn.Alpha = 0.5f;
                    _Conbtn.Enabled = false;
                }
                else
                {
                    _Conbtn.Alpha = 1.0f;
                    _Conbtn.Enabled = true;
                }
            }
            catch (Exception ex)
            {

            }
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);
        }




        private void AlredayView_Click(object sender, EventArgs e)
        {
            try
            {
                StartActivity(new Intent(Application.Context, typeof(LoginActivity)));
                this.Activity.Finish();
            }
            catch (Exception ex)
            {

            }

        }
    }
}