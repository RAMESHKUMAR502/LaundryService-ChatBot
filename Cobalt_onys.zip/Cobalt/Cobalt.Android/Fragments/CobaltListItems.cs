using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;

using FloatingActionButton = Clans.Fab.FloatingActionButton;
using FloatingActionMenu = Clans.Fab.FloatingActionMenu;
using Fragment = Android.Support.V4.App.Fragment;
using Android.Support.V4.Content;
using Android.Animation;

namespace Cobalt.Android.Fragments
{
    public class CobaltListItems : Fragment, View.IOnClickListener
    {
        private FloatingActionMenu menuRed;

        private FloatingActionButton fab1;
        private FloatingActionButton fab2;
        private FloatingActionButton fab3;

        private ListView listView;

        private List<FloatingActionMenu> menus = new List<FloatingActionMenu>();
        private Handler mUiHandler = new Handler();


        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            return inflater.Inflate(Resource.Layout.CobaltListItems, container, false);
        }

        public override void OnViewCreated(View view, Bundle savedInstanceState)
        {
            base.OnViewCreated(view, savedInstanceState);

            this.listView = view.FindViewById<ListView>(Resource.Id.list);

            menuRed = view.FindViewById<FloatingActionMenu>(Resource.Id.menu_red);

            fab1 = view.FindViewById<FloatingActionButton>(Resource.Id.fab1);
            fab2 = view.FindViewById<FloatingActionButton>(Resource.Id.fab2);
            fab3 = view.FindViewById<FloatingActionButton>(Resource.Id.fab3);


            FloatingActionButton programFab1 = new FloatingActionButton(this.Activity);
            programFab1.ButtonSize = FloatingActionButton.SizeMini;
            programFab1.LabelText = this.GetString(Resource.String.Del);
            programFab1.SetImageResource(Resource.Drawable.ic_edit);
            menuRed.AddMenuButton(programFab1);
            programFab1.Click += ProgramFab1_Click;

            ContextThemeWrapper context = new ContextThemeWrapper(this.Activity, Resource.Style.MenuButtonsStyle);



            fab1.Enabled = false;
            menuRed.SetOnMenuButtonClickListener(this);
            menuRed.SetClosedOnTouchOutside(true);
            menuRed.HideMenuButton(false);
           
        }

        public override void OnActivityCreated(Bundle savedInstanceState)
        {
            base.OnActivityCreated(savedInstanceState);

            var locales = Java.Util.Locale.GetAvailableLocales().Select(c => c.DisplayName).ToList<String>();

            //this.listView.Adapter = new ArrayAdapter(this.Activity, Android.Resource.Layout.SimpleListItem1,
            //    Android.Resource.Id.Text1, locales);


            menus.Add(menuRed);


            fab1.Click += ActionButton_Click;
            fab2.Click += ActionButton_Click;
            fab3.Click += ActionButton_Click;

            int delay = 400;
            foreach (var menu in menus)
            {
                mUiHandler.PostDelayed(() => menu.ShowMenuButton(true), delay);
                delay += 150;
            }

            // new Handler ().PostDelayed (() => fabEdit.Show (true), delay + 150);

            CreateCustomAnimation();
        }


        private void CreateCustomAnimation()
        {
            AnimatorSet set = new AnimatorSet();

        }


        private void ActionButton_Click(object sender, EventArgs e)
        {
            FloatingActionButton fabButton = sender as FloatingActionButton;
            if (fabButton != null)
            {
                if (fabButton.Id == Resource.Id.fab2)
                {
                    fabButton.Visibility = ViewStates.Gone;
                }
                else if (fabButton.Id == Resource.Id.fab3)
                {
                    fabButton.Visibility = ViewStates.Visible;
                }
                Toast.MakeText(this.Activity, fabButton.LabelText, ToastLength.Short).Show();
            }
        }


        public void OnClick(View v)
        {
            FloatingActionMenu menu = (FloatingActionMenu)v.Parent;
            if (menu.Id == Resource.Id.menu_red && menu.IsOpened)
            {
                Toast.MakeText(this.Activity, menu.MenuButtonLabelText, ToastLength.Short).Show();
            }

            menu.Toggle(animate: true);
        }


        public override void OnResume()
        {
            base.OnResume();
            this.listView.Scroll += ListView_Scroll;
           
        }

        public override void OnPause()
        {
            base.OnPause();
            this.listView.Scroll -= ListView_Scroll;
            ;
        }

       

        private void ListView_Scroll(object sender, AbsListView.ScrollEventArgs e)
        {
            try
            {

            }
            catch(Exception ex)
            {

            }
        }

        private void ProgramFab1_Click(object sender, EventArgs e)
        {
            var fab = sender as FloatingActionButton;

            if (fab != null)
            {
                fab.SetLabelColors(ContextCompat.GetColor(this.Activity, Resource.Color.grey),
                                    ContextCompat.GetColor(this.Activity, Resource.Color.light_grey),
                                    ContextCompat.GetColor(this.Activity, Resource.Color.white_transparent));
                fab.SetLabelTextColor(ContextCompat.GetColor(this.Activity, Resource.Color.black));
            }
        }
    }
}