﻿namespace Cobalt.Models
{
    public class UserID
    {
        public string id { get; set; }
    }
}
