﻿namespace Cobalt.Models
{
    public class VehicleSearch
    {
        public string make { get; set; }
        public string dateOfFirstRegistration { get; set; }
        public string yearOfManufacture { get; set; }
        public string cylinderCapacity { get; set; }
        public string co2Emissions { get; set; }
        public string fuelType { get; set; }
        public string taxStatus { get; set; }
        public string colour { get; set; }
        public string typeApproval { get; set; }
        public string wheelPlan { get; set; }
        public string revenueWeight { get; set; }
        public string taxDetails { get; set; }
        public string motDetails { get; set; }
        public bool taxed { get; set; }
        public bool mot { get; set; }
        public string vin { get; set; }
        public string model { get; set; }
        public string transmission { get; set; }
        public string numberOfDoors { get; set; }
        public string sixMonthRate { get; set; }
        public string twelveMonthRate { get; set; }

        /*
         * "make": "VOLKSWAGEN",
          "dateOfFirstRegistration": "23 July 2009",
          "yearOfManufacture": "2009",
          "cylinderCapacity": "1968 cc",
          "co2Emissions": "167 g/km",
          "fuelType": "DIESEL",
          "taxStatus": "Tax not due",
          "colour": "SILVER",
          "typeApproval": "M1",
          "wheelPlan": "2 AXLE RIGID BODY",
          "revenueWeight": "Not available",
          "taxDetails": "Tax due: 01 April 2017",
          "motDetails": "Expires: 28 April 2017",
          "taxed": true,
          "mot": true,
          "vin": "WVGZZZ5NZAW007903",
          "model": "TIGUAN SE TDI 4MOTION 140",
          "transmission": "MANUAL",
          "numberOfDoors": "5",
          "sixMonthRate": "",
          "twelveMonthRate": ""
         */
    }
}
