﻿namespace Cobalt.Models
{
    public class LoggedInUser
    {
        public UserID user { get; set; }
        public string token { get; set; }
        public LoggedInUser()
        {
           
        }
    }

   
}
