#Introduction 
This Project is for Cobalt Mobile App (Android & IOS).This is built using XAMARIN, C#. 

#Getting Started
This Section will help you through getting your code up and running on your system. This Section consists of :
1.	Pre-Requisite or Installation process
2.	Software dependencies
3.	API references

1. Pre-Requisite or Installation process : Xamarin development rely upon the platform SDKs from Apple and Google to target iOS or Android, so our system requirements match theirs.
This section outlines system compatibility for the Xamarin platform and recommended development environment and SDK versions.

Using a Windows computer for Xamarin development requires the following software/SDK versions. 
Check your operating system version.If using Visual Studio, it should be installed first - the Visual Studio 2015 installer includes an option to install 
Xamarin automatically. otherwise follow the instructions for t

Development Environments : For Windows You need "Visual Studio 2015 Community Edition"
Xamarin.iOS --> You need a Mac Computer to Pair
Xamarin.Android --> its Supported and works on Windows
Xamarin.Forms --> It Supports Android,Windows, Windows Phone(iOS with Mac Computer)

To develop for iOS on Windows computers there must be a Mac computer accessible on the network, for remote compilation and debugging. 
This also works if you have Visual Studio running inside a Windows VM on a Mac computer.

TODO: Continue Writing

#Build and Test
TODO: Describe and show how to build your code and run the tests. 

#Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://www.visualstudio.com/en-us/docs/git/create-a-readme). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)